// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.exceptions.i18n;

import java.util.ListResourceBundle;

/**
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class IntegrationExceptionResource extends ListResourceBundle {

    static final Object[][] contents = {
        { "80000", "Unable to connect to Coherence Cache by name: {0}." },
        { "80001", "The configured Optimistic Locking Policy for class {0} is not supported.  Only Version based policies where the value is stored in object is supported."},
        { "80002", "Unable to find a descriptor in the EclipseLinkJPACacheLoader for named-cache: {0} within session: {1}"},
        { "80003", "Failed to define generated wrapper for Class: {0}."},
        { "80004", "Failed to gain access to defineClass method of ClassLoader.  This access is needed to define Cache wrappers."},
        { "80005", "The EclipseLink Serializer for class : {0} was not set on the cache named : {1}"},
        { "80006", "Failed to load class for wrapper :{0}"},
        { "80007", "Failed to create instance of wrapper class: {0}"},
        { "80008", "Relationship information for attribute : {0} of class: {1} can not be found in the cache wrapper."},
        { "80009", "Filter being executed uses a SubClassFilter to determine if entry is correct class type.  Unable to load class {0} for filter using classLoader from entry: {1}."},
        { "80010", "Unable to instantiate FilterFactory instance with name: {0}."},
        { "80011", "Unable to instantiate QueryTranslationFailurePolicy instance with name: {0}"}
    };

    /**
    * Return the lookup table.
    */
    protected Object[][] getContents() {
        return contents;
    }

}
