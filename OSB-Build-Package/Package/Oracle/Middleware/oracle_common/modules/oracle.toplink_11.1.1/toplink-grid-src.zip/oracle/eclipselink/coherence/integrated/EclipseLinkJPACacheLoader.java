// Copyright (c) 1998, 2011, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import oracle.eclipselink.coherence.IntegrationProperties;
import oracle.eclipselink.coherence.integrated.internal.InternalProperties;
import oracle.eclipselink.coherence.integrated.internal.cache.CoherenceCacheHelper;
import oracle.eclipselink.coherence.integrated.querying.DeleteObjectThroughCoherence;
import oracle.eclipselink.coherence.integrated.querying.InsertObjectToCoherence;
import oracle.eclipselink.coherence.integrated.querying.UpdateObjectToCoherence;
import org.eclipse.persistence.descriptors.ClassDescriptor;
import org.eclipse.persistence.internal.jpa.EntityManagerImpl;
import org.eclipse.persistence.jpa.JpaHelper;
import org.eclipse.persistence.sessions.server.Server;

import com.tangosol.net.cache.CacheLoader;
import com.tangosol.util.Base;

/**
 * This is the Coherence Cache Loader that should be used with EclipseLink
 * Coherence interceptors and redirectors set in your PeristenceUnit. No special
 * Persistence Unit updates should be required when used with this Cache Loader.
 * <p>
 * <b>Coherence Configuration:</b> In order to use the integrated
 * EclipseLinkJPACacheLoader or EclipseLinkJPACacheStore the Coherence
 * configuration XML file must specify the loader/store class as well as
 * providing parameters for the cache-name and JPA persistence unit name.
 * <p>
 * The following is an example of how the integrated EclipseLinkJPACacheLoader
 * can be configured.
 * 
 * <pre>
 * &lt;cachestore-scheme&gt;
 *    &lt;class-scheme&gt;
 *       &lt;class-name&gt;oracle.eclipselink.coherence.integrated.EclipseLinkJPACacheLoader&lt;/class-name&gt; 
 *       &lt;init-params&gt; 
 *          &lt;init-param&gt;
 *             &lt;param-type&gt;java.lang.String&lt;/param-type&gt;
 *             &lt;param-value&gt;{cache-name}&lt;/param-value&gt; 
 *          &lt;/init-param&gt;
 *          &lt;init-param&gt;
 *             &lt;param-type&gt;java.lang.String&lt;/param-type&gt;
 *             &lt;param-value&gt;coherence-pu&lt;/param-value&gt; 
 *          &lt;/init-param&gt; 
 *       &lt;/init-params&gt;
 *    &lt;/class-scheme&gt;
 * &lt;/cachestore-scheme&gt;
 * </pre>
 * 
 * @author gyorke, djclarke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class EclipseLinkJPACacheLoader extends Base implements CacheLoader {

    protected EntityManagerFactory emf;
    protected ClassDescriptor descriptor;
    protected boolean shouldTranslatePKs = true;

    public EclipseLinkJPACacheLoader(String cacheName, String puName) {
        Map properties = new HashMap();
        properties.put("eclipselink.session-name", "EclipseLinkCacheLoader-" + puName);
        this.emf = Persistence.createEntityManagerFactory(puName, properties);

        Server session = JpaHelper.getServerSession(this.emf);
        session.setExternalTransactionController(null);
        Object property = session.getProperty(IntegrationProperties.USE_TOPLINK_ID_CLASSES);
        if (property != null && property instanceof String && ((String)property).toLowerCase().equals("false")){
        	this.shouldTranslatePKs = false;
        }
        // must initialize all descriptors here as relationships could cause
        // target object access before loader for that class is initialized.
        Iterator iter = session.getDescriptors().values().iterator();

        while (iter.hasNext()) {
            ClassDescriptor desc = (ClassDescriptor) iter.next();
            if (cacheName.equals(CoherenceCacheHelper.getCacheName(desc))) {
                this.descriptor = desc;
            }
            if (desc.getProperty(InternalProperties.DESCRIPTOR_INITIALIZED) == null) {
                desc.setProperty(InternalProperties.DESCRIPTOR_INITIALIZED, Boolean.TRUE);
                // Disable any configured query redirectors within the
                // CacheLoader
                desc.setDefaultReadAllQueryRedirector(null);
                desc.setDefaultReadObjectQueryRedirector(null);
                desc.setDefaultReportQueryRedirector(null);
                if (desc.getDefaultInsertObjectQueryRedirector() != null){
                    // write through coherence is configured
                    desc.setDefaultInsertObjectQueryRedirector(null);
                    desc.setDefaultDeleteObjectQueryRedirector(null);
                    desc.setDefaultUpdateObjectQueryRedirector(null);
                }else{
                    //write through eclipselink is configured
                    desc.setDefaultInsertObjectQueryRedirector(new InsertObjectToCoherence());
                    desc.setDefaultDeleteObjectQueryRedirector(new DeleteObjectThroughCoherence());
                    desc.setDefaultUpdateObjectQueryRedirector(new UpdateObjectToCoherence());
                }

                // Ensure no caching is done in the CacheLoader/Store
                desc.setIsIsolated(true);
                session.getProject().setHasIsolatedClasses(true);
                desc.setCacheInterceptorClass(null);
                if (!desc.isChildDescriptor() && ! desc.isAggregateCollectionDescriptor()  && ! desc.isAggregateDescriptor()){
                    session.getIdentityMapAccessor().initializeIdentityMap(desc.getJavaClass());
                }

                // Optimistic lock checking cannot be done within the CacheStore
                // so
                // any configured policy is removed
                desc.setOptimisticLockingPolicy(null);

                // Primary keys assigned using sequencing cannot be done within
                // the
                // CacheStore so
                desc.setSequenceNumberName(null);
                desc.setSequenceNumberField(null);
                CoherenceCacheHelper.defineWrapperClass(desc, session.getPlatform().getConversionManager().getLoader());
            }
        }
    }

    protected EntityManagerFactory getEMF() {
        return this.emf;
    }

    protected ClassDescriptor getDescriptor() {
        return descriptor;
    }

    public Object load(Object id) {
        EntityManager em = getEMF().createEntityManager();
        try {
            return load(id, em);
        } finally {
            em.close();
        }
    }

    public Map loadAll(Collection ids) {
        EntityManager em = getEMF().createEntityManager();

        try {
            Map map = new HashMap(ids.size());
            Iterator iterator = ids.iterator();
            while (iterator.hasNext()) {
                Object key = iterator.next();
                Object result = this.load(key, em);
                if (result != null) {
                    map.put(key, result);
                }
            }
            return map;
        } finally {
            em.close();
        }
    }
    
    protected Object load(Object id, EntityManager em){
        Object result = em.find(getDescriptor().getJavaClass(), id);
        // TODO: load relationships.
        if (result != null) {
            result = CoherenceCacheHelper.decomposeEntity(result, getDescriptor(), ((EntityManagerImpl) em).getActivePersistenceContext(null), shouldTranslatePKs);
        }
        return result;
    }

}
