// Copyright (c) 1998, 2011, Oracle and/or its affiliates. 
// All rights reserved. 

package oracle.eclipselink.coherence.integrated.cache;

import java.util.Map;
import java.util.Vector;

import oracle.eclipselink.coherence.IntegrationProperties;
import oracle.eclipselink.coherence.exceptions.IntegrationException;
import oracle.eclipselink.coherence.integrated.internal.cache.CoherenceCacheHelper;

import org.eclipse.persistence.descriptors.ClassDescriptor;
import org.eclipse.persistence.descriptors.VersionLockingPolicy;
import org.eclipse.persistence.indirection.ValueHolderInterface;
import org.eclipse.persistence.internal.descriptors.OptimisticLockingPolicy;
import org.eclipse.persistence.internal.identitymaps.CacheKey;
import org.eclipse.persistence.internal.identitymaps.FullIdentityMap;
import org.eclipse.persistence.internal.identitymaps.IdentityMap;
import org.eclipse.persistence.internal.indirection.CacheBasedValueHolder;
import org.eclipse.persistence.internal.sessions.AbstractSession;
import org.eclipse.persistence.mappings.ForeignReferenceMapping;
import org.eclipse.persistence.sessions.interceptors.CacheInterceptor;
import org.eclipse.persistence.sessions.interceptors.CacheKeyInterceptor;

import com.tangosol.net.NamedCache;

/**
 * <p>
 * <b>Purpose:</b> This Cache Interceptor should be set on the descriptor for
 * any class that is cached within Coherence. Once this Interceptor is applied
 * EclipseLink will ensure that all Entities read into EclipseLink or updated by
 * EclipseLink will be put into the Coherence Cache.
 * 
 * TopLink cache settings will not be used.
 * 
 * Developers should set the Coherence Cache name that corresponds to this class
 * in a descriptor property called "coherence.cache.name". Each class should
 * have its own Cache unless the PK's of the instances are unique amoung all
 * classes stored in a single cache
 * 
 * This Interceptor can be set on the class descriptor through a Session or
 * Descriptor customizer or annotations
 * 
 * @see org.eclipse.persistence.descriptors.ClassDescriptor.setCacheInterceptorClass
 * @see org.eclipse.persistence.annoations.CacheInterceptor
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class CoherenceInterceptor extends CacheInterceptor {

    protected NamedCache namedCache;

    protected ClassDescriptor descriptor;

    protected OptimisticLockingPolicy lockingPolicy;
    
    protected boolean shouldTranslatePKs = true;
    
    // Although it seems that this code is still using the EclipseLink cache,
    // the EclipseLink
    // cache is only used to manage concurrency and the object will be removed
    // from the cache
    // as soon as the CacheKey is released.

    /**
     * Instantiate an new Cache Interceptor passing in the identity map that
     * will be intercepted and the session that holds that identity map. This is
     * an internal method as this class should not be instantiated by the user.
     */
    public CoherenceInterceptor(IdentityMap targetIdentityMap, AbstractSession interceptedSession) {
        super(new FullIdentityMap(targetIdentityMap.getSize(), targetIdentityMap.getDescriptor()), interceptedSession);
        if (targetIdentityMap.getDescriptor() != null) {
            this.descriptor = targetIdentityMap.getDescriptor();
            this.lockingPolicy = this.descriptor.getOptimisticLockingPolicy();
            if (this.lockingPolicy != null) {
                if (this.lockingPolicy.isStoredInCache() || !(this.lockingPolicy instanceof VersionLockingPolicy)) {
                    throw IntegrationException.optimisticLockingPolicyNotSupported(this.descriptor.getJavaClassName());
                }
            }
            try {
                this.namedCache = CoherenceCacheHelper.getNamedCache(descriptor, interceptedSession);
                if (this.namedCache == null) {
                    throw IntegrationException.unableToFindCoherenceCache(CoherenceCacheHelper.getCacheName(descriptor), null);
                }
            } catch (Exception ex) {
                throw IntegrationException.unableToFindCoherenceCache(CoherenceCacheHelper.getCacheName(descriptor), ex);
            }
        }
        Object property = interceptedSession.getProperty(IntegrationProperties.USE_TOPLINK_ID_CLASSES);
        if (property != null && property instanceof String && ((String)property).toLowerCase().equals("false")){
        	this.shouldTranslatePKs = false;
        }
    }

    protected CacheKeyInterceptor createCacheKeyInterceptor(CacheKey wrappedCacheKey) {
        return new CoherenceOnlyCacheKeyWrapper(wrappedCacheKey);
    }

    public Object clone() {
        return new CoherenceInterceptor((IdentityMap) this.targetIdentityMap.clone(), this.interceptedSession);
    }

    /**
     * Acquire a deferred lock on the object.
     * This is used while reading if the object has relationships without indirection.
     * This first thread will get an active lock.
     * Other threads will get deferred locks, all threads will wait until all other threads are complete before releasing their locks.
     */
    public CacheKey acquireDeferredLock(Object primaryKey){
        // Get a coherence lock as well to prevent update conflicts.
        CoherenceOnlyCacheKeyWrapper tempKey = (CoherenceOnlyCacheKeyWrapper) super.acquireDeferredLock(primaryKey);
        try{
            tempKey.setAcquiredForRead(true);
            if (tempKey.getObject() == null) {
                tempKey.internalSetObject(CoherenceCacheHelper.getFromCoherence(descriptor, interceptedSession, namedCache, primaryKey, shouldTranslatePKs));
            }
            return tempKey;
        }catch (RuntimeException ex){
            tempKey.releaseDeferredLock();
            throw ex;
        }catch (Error ex){
            tempKey.releaseDeferredLock();
            throw ex;
        }
        // release of the cachekey by EclipseLink will release the lock in
        // coherence without this lock there would be no consistency in write
        // timing
    }

    /**
     * Acquire an active lock on the object. This is used by reading (when using
     * indirection or no relationships) and by merge.
     */
    @Override
    public CacheKey acquireLock(Object primaryKey, boolean forMerge) {
        // Get a coherence lock as well to prevent update conflicts.
        CoherenceOnlyCacheKeyWrapper tempKey = (CoherenceOnlyCacheKeyWrapper) super.acquireLock(primaryKey, forMerge);
        try{
            tempKey.setAcquiredForRead(true);
            if (tempKey.getObject() == null) {
                tempKey.internalSetObject(CoherenceCacheHelper.getFromCoherence(descriptor, interceptedSession, namedCache, primaryKey, shouldTranslatePKs));
            }
            return tempKey;
        }catch (RuntimeException ex){
            tempKey.release();
            throw ex;
        }catch (Error ex){
            tempKey.releaseDeferredLock();
            throw ex;
        }
        // release of the cachekey by EclipseLink will release the lock in
        // coherence without this lock there would be no consistency in write
        // timing
    }

    /**
     * Acquire an active lock on the object, if not already locked. This is used
     * by merge for missing existing objects.
     */
    @Override
    public CacheKey acquireLockNoWait(Object primaryKey, boolean forMerge) {
        // Get a coherence lock as well to prevent update conflicts.
        CacheKey tempKey = super.acquireLockNoWait(primaryKey, forMerge);
        return tempKey;
        // release of the cachekey by EclipseLink will release the lock in
        // coherence
        // without this lock there would be no consistency in write timing
    }

    /**
     * Acquire an active lock on the object, if not already locked. This is used
     * by merge for missing existing objects.
     */
    @Override
    public CacheKey acquireLockWithWait(Object primaryKey, boolean forMerge, int wait) {
        // Get a coherence lock as well to prevent update conflicts.
        CacheKey tempKey = super.acquireLockWithWait(primaryKey, forMerge, wait);
        return tempKey;
        // release of the cachekey by EclipseLink will release the lock in
        // coherence
        // without this lock there would be no consistency in write timing
    }

    /**
     * ADVANCED:
     * Using a list of Entity PK this method will attempt to bulk load the entire list from the cache.
     * In certain circumstances this can have large performance improvements over loading each item individually.
     * @param pkList List of Entity PKs to extract from the cache
     * @param ClassDescriptor Descriptor type to be retrieved.
     * @return Map of Entity PKs associated to the Entities that were retrieved
     * @throws QueryException
     */
    public Map<Object, Object> getAllFromIdentityMapWithEntityPK(Object[] pkList, ClassDescriptor descriptor, AbstractSession session){
    	return CoherenceCacheHelper.getAllFromCoherenceWithCohKey(pkList, descriptor, interceptedSession, namedCache, shouldTranslatePKs);
    }

    /**
     * Return the cache key (with object) matching the searchKey.
     */
    @Override
    public CacheKey getCacheKey(Object searchKey, boolean forMerge) {
        CacheKey returnKey = targetIdentityMap.getCacheKey(searchKey, forMerge);
        if (returnKey == null) {
            // let's hit coherence for this object
            if (!forMerge){
                Object cachedObject = CoherenceCacheHelper.getFromCoherence(descriptor, interceptedSession, namedCache, searchKey, shouldTranslatePKs);
                if (cachedObject != null) {
                    // TODO : extract writelock value if required.
                    returnKey = new CacheKey(searchKey, cachedObject, null, System.currentTimeMillis(), false);
                }
            }else{
                returnKey = new CacheKey(searchKey, null, null,  System.currentTimeMillis(), false);
            }
        }
        return returnKey;
    }

    /**
     * Return the cache key (with object) matching the searchKey.
     */
    @Override
    public CacheKey getCacheKeyForLock(Object searchKey) {
        CacheKey returnKey = targetIdentityMap.getCacheKeyForLock(searchKey);
        if (returnKey == null) {
                returnKey = new CacheKey(searchKey, null, null, System.currentTimeMillis(), false);
        }
        return returnKey;
    }

    /**
     * Notify the cache that a lazy relationship has been triggered in the object
     * and the cache may need to be updated
     */
    @Override
    public void lazyRelationshipLoaded(Object object, ForeignReferenceMapping mapping){
        Object attributeValue = mapping.getAttributeValueFromObject(object);
        if (! (mapping.getIndirectionPolicy().getOriginalValueHolder(attributeValue, interceptedSession) instanceof CacheBasedValueHolder)){
            Object key = mapping.getDescriptor().getObjectBuilder().extractPrimaryKeyFromObject(object, interceptedSession);
            CoherenceCacheHelper.updateRelationship(descriptor, interceptedSession, namedCache, key, attributeValue, object, mapping, shouldTranslatePKs);
        }
    }

    /**
     * Store the object in the cache at its primary key. This is used by
     * InsertObjectQuery, typically into the UnitOfWork identity map. Merge and
     * reads do not use put, but acquireLock. Also an advanced (very) user API.
     * 
     * @param primaryKey
     *            is the primary key for the object.
     * @param object
     *            is the domain object to cache.
     * @param writeLockValue
     *            is the current write lock value of object, if null the version
     *            is ignored.
     */
    @Override
    public CacheKey put(Object primaryKey, Object object, Object writeLockValue, long readTime) {
        CoherenceCacheHelper.putIntoCoherence(descriptor, interceptedSession, namedCache, primaryKey, object, false, shouldTranslatePKs);
        return new CacheKey(primaryKey, object, writeLockValue, readTime, false);
    }

    /**
     * Used to release the reference to the named cache durring initialize all
     * identity maps.
     * 
     * @author Gordon
     * 
     */
    @Override
    public void release() {
        this.namedCache.release();
    }

    /**
     * Remove the CacheKey with the primaryKey from the map. This is used by
     * DeleteObjectQuery and merge. This is also an advanced (very) user API.
     */
    @Override
    public Object remove(Object primaryKey, Object object) {
        if (object != null) {
            CoherenceCacheHelper.removeFromCoherence(descriptor, interceptedSession, namedCache, primaryKey, object, shouldTranslatePKs);
        }
        return this.targetIdentityMap.remove(primaryKey, object);
    }

    /**
     * Remove the CacheKey from the map.
     */
    @Override
    public Object remove(CacheKey cacheKey) {
        CacheKey key = cacheKey;
        if (cacheKey.isWrapper()) {
            key = cacheKey.getWrappedCacheKey();
        }
        if (key.getObject() != null) {
            CoherenceCacheHelper.removeFromCoherence(descriptor, interceptedSession, namedCache, key.getKey(), key.getObject(), shouldTranslatePKs);
        }
        return this.targetIdentityMap.remove(key);
    }

    public class CoherenceOnlyCacheKeyWrapper extends CacheKeyInterceptor {

        protected boolean updated = false;
        protected boolean acquiredForRead = false;

        public CoherenceOnlyCacheKeyWrapper(CacheKey cacheKey) {
            super(cacheKey);
        }

        public Object clone() {
            CoherenceOnlyCacheKeyWrapper wrapper = new CoherenceOnlyCacheKeyWrapper((CacheKey) wrappedKey.clone());
            wrapper.acquiredForRead = this.acquiredForRead;
            wrapper.updated = this.updated;
            return wrapper;
        }

        public void setAcquiredForRead(boolean acquiredForRead) {
            this.acquiredForRead = acquiredForRead;
        }

        /**
         * Release the lock on the cache key object.
         */
        @Override
        public void release() {
            wrappedKey.release();
            try {
                if (updated && wrappedKey.getObject() != null) {
                    try {
                        CoherenceCacheHelper.putIntoCoherence(descriptor, interceptedSession, namedCache, wrappedKey.getKey(), wrappedKey.getObject(), acquiredForRead, shouldTranslatePKs);
                    } finally {
                        // ensure the locked cache key is always removed from
                        // the owning map.
                        this.updated = false;
                        // This will remove the object from the cache as soon as
                        // it
                        // is no longer being locked by other threads
                        // eliminating
                        // any caching.
                    }
                }
            } finally {
                wrappedKey.getOwningMap().remove(wrappedKey);
            }
        }

        /**
         * Release the lock on the cache key object.
         */
        @Override
        public void releaseDeferredLock() {
            wrappedKey.releaseDeferredLock();
            try {
                if (updated && wrappedKey.getObject() != null) {
                    try {
                        CoherenceCacheHelper.putIntoCoherence(descriptor, interceptedSession, namedCache, wrappedKey.getKey(), wrappedKey.getObject(), true, shouldTranslatePKs);
                    } finally {
                        // ensure the locked cache key is always removed from
                        // the owning map.
                        this.updated = false;
                        // This will remove the object from the cache as soon as
                        // it
                        // is no longer being locked by other threads
                        // eliminating
                        // any caching.
                    }
                }
            } finally {
                wrappedKey.getOwningMap().remove(wrappedKey);
            }
        }

        @Override
        public void setReadTime(long readTime) {
            // EclipseLink always sets the read time once the object is read or
            // refreshed if read time is not updated then this object was locked
            // for a
            // read but wasn't actually updated.
            this.updated = true;
            this.wrappedKey.setReadTime(readTime);
        }

        @Override
        public void setObject(Object object) {
            // EclipseLink always sets the object into the shared cache cache
            // key once the merge completes
            this.updated = true;
            this.wrappedKey.setObject(object);
        }

        public void internalSetObject(Object object) {
            this.wrappedKey.setObject(object);
        }
        
        /**
         * INTERNAL:
         * Return the value of the invalidationState Variable
         * The return value will be a constant
         * CHECK_INVALIDATION_POLICY - The Invalidation policy is must be checked for this cache key's sate
         * CACHE_KEY_INVALID - This cache key has been labeled invalid.
         */
        public int getInvalidationState() {
            return this.wrappedKey.getInvalidationState();
        }
    }

}
