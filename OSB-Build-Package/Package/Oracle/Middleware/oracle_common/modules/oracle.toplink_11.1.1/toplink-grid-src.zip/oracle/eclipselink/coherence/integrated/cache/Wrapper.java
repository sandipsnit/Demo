// Copyright (c) 1998, 2011, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.cache;

import java.io.Serializable;


/**
 * <p>
 * <b>Purpose:</b> This class will act as a wrapper for any Entity stored within
 * Coherence. This interface will provide a means to store relationship
 * information without forcing related objects to be referenced within
 * Coherence.
 * 
 * All Entities stored within Coherence will be wrapped by an implementation of
 * this interface. Users who access Coherence via custom Value Extractors will
 * need to anticipate unwrapping the actual entity. This does not apply to the
 * default Coherence Reflection Extractor as the wrapper implementation will
 * include mapped property methods. If users have not mapped all of the
 * properties that they wish to access then they must implement a custom Value
 * Extractor that unwraps the entity.
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */

public interface Wrapper extends Serializable {

    /**
     * This method provides an access point for the wrapped entity. This method
     * should be used by custom Value Extractors.
     */
    public Object unwrap();

    /**
     * This method is used to store the Entity within the wrapper.
     */
    public void wrap(Object entity);

    /**
     * This method provides access to the foreign key values for the related
     * entities. If users are accessing caches from a non EclipseLink client
     * then this will provide the information to query for related entities.
     * These values will exist for all relationships including non-owned
     * relationships.
     * 
     * This method returns an org.eclipse.persistence.sessions.Record where the
     * contents are the FK values.
     */
    public Object[] getForeignKeyValuesFor(String propertyName);

    /**
     * This method provides access to the primary key values for the related
     * entities. If users are accessing caches from a non EclipseLink client
     * then this will provide the information to load related entities from
     * other caches. These values will exist for all relationships including
     * non-owned relationships.
     * 
     * This method returns an Object[] where the contents of the nested array is
     * the PK values in order of the EclipseLink Class Descriptor's PK mappings.
     */
    public Object[] getPrimaryKeyValuesFor(String propertyName);

    /**
     * This method provides access to the foreign key values for queries of the
     * related entities. If users are accessing caches from a non EclipseLink
     * client then this will provide the information to query related entities.
     * These values will exist for all relationships including non-owned
     * relationships.
     * 
     * This method takes and Object[] of FK values in the order of the EclipseLink mappings.
     */
    public void setForeignKeyValuesFor(String propertyName, Object[] fks);

    /**
     * This method provides access to the primary key values for the related
     * entities. If users are accessing caches from a non EclipseLink client
     * then this will provide the information to store related entities PKs for
     * caches. These values will exist for all relationships including non-owned
     * relationships.
     * 
     * This method takes an Object[] where the contents of the nested array is
     * the PK values for an Entity.
     */
    public void setPrimaryKeyValuesFor(String propertyName, Object[] pks);
}
