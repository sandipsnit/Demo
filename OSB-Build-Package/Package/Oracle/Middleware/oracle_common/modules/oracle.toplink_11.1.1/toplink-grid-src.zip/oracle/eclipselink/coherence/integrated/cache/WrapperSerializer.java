// Copyright (c) 1998, 2011, Oracle and/or its affiliates. 
// All rights reserved. 

package oracle.eclipselink.coherence.integrated.cache;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

import oracle.eclipselink.coherence.IntegrationProperties;
import oracle.eclipselink.coherence.integrated.internal.cache.SerializableWrapper;
import oracle.eclipselink.coherence.integrated.internal.cache.WrapperGenerator;
import oracle.eclipselink.coherence.integrated.internal.cache.WrapperInternal;

import com.tangosol.io.ClassLoaderAware;
import com.tangosol.io.ReadBuffer;
import com.tangosol.io.Serializer;
import com.tangosol.io.WriteBuffer;
import com.tangosol.util.ExternalizableHelper;

/**
 * <p>
 * <b>Purpose:</b> This class is used to provide serialization support for the
 * Entity Wrappers within Coherence when wish to access the Coherence Caches
 * directly. This includes users who have custom Value Extractors.
 * 
 * Users who have custom POF serializers will need to create the pof
 * configuration xml for their types. And set the serializer to be the
 * WrapperPofSerializer instead.
 * 
 * @author gyorke
 * @since TopLink 11g (11.1.1.1.0)
 */
public class WrapperSerializer implements Serializer, ClassLoaderAware {
    
    protected WeakReference<ClassLoader> loaderReference;
    protected Map<String, Class> classes;
    protected boolean isNotEclipseLink = false;
    
    /**
     * @return the isNotEclipseLink
     */
    public boolean isNotEclipseLink() {
        return isNotEclipseLink;
    }

    /**
     * @param isNotEclipseLink the isNotEclipseLink to set
     */
    public void setNotEclipseLink(boolean isNotEclipseLink) {
        this.isNotEclipseLink = isNotEclipseLink;
    }

    public WrapperSerializer()
    {
        this.classes = new HashMap<String, Class>();
        this.isNotEclipseLink = System.getProperty(IntegrationProperties.IS_NOT_ECLIPSELINK) != null;
    }

    public WrapperSerializer(ClassLoader loader)
    {
        this();
        setContextClassLoader(loader);
    }

    public void serialize(WriteBuffer.BufferOutput out, Object o)
        throws IOException
    {
        if (o instanceof WrapperInternal){
            WrapperInternal toSerialize = (WrapperInternal)o;
            SerializableWrapper wrapper = new SerializableWrapper();
            wrapper.wrap(toSerialize.unwrap());
            wrapper.setForeignKeys(toSerialize.getForeignKeys());
            wrapper.setPrimaryKeys(toSerialize.getPrimaryKeys());
            wrapper.setWrapperClassName(toSerialize.getClass().getName());
            wrapper.setShouldMerge(toSerialize.shouldMerge());
            o = wrapper;
        }
        ExternalizableHelper.writeObject(out, o);
    }

    public Object deserialize(ReadBuffer.BufferInput in) throws IOException {
        Object serialized = ExternalizableHelper.readObject(in, getContextClassLoader());
        if (serialized instanceof SerializableWrapper) {
            SerializableWrapper received = (SerializableWrapper) serialized;
            if (isNotEclipseLink) {
                return received.unwrap();
            }
            Class wrapperClass = this.classes.get(received.getWrapperClassName()); // save class for name
            if (wrapperClass == null) {
                synchronized (this.classes) {
                    try {
                        wrapperClass = Class.forName(received.getWrapperClassName(), false, getContextClassLoader());
                    } catch (ClassNotFoundException ex) {

                        WrapperGenerator generator = new WrapperGenerator();
                        generator.createWrapperFor(received.unwrap().getClass(), getContextClassLoader());
                        try {
                            wrapperClass = Class.forName(received.getWrapperClassName(), false, getContextClassLoader());
                        } catch (ClassNotFoundException ex2) {
                            return received.unwrap();
                        }
                    }
                    this.classes.put(received.getWrapperClassName(), wrapperClass);
                }
            }
            boolean exception = false;
            try {
                WrapperInternal newWrapper = (WrapperInternal) wrapperClass.newInstance();
                newWrapper.setForeignKeys(received.getForeignKeys());
                newWrapper.setPrimaryKeys(received.getPrimaryKeys());
                newWrapper.wrap(received.unwrap());
                newWrapper.setShouldMerge(received.shouldMerge());
                serialized = newWrapper;
            } catch (InstantiationException e) {
                exception = true;
            } catch (IllegalAccessException e) {
                exception = true;
            }
            if (exception) {
                // we were unable to load the wrapper class, we may be on a
                // client, only return the delegate.
                serialized = received.unwrap();
            }
        }
        return serialized;
    }

    public ClassLoader getContextClassLoader()
    {
        return loaderReference != null ? (ClassLoader)loaderReference.get() : null;
    }

    public void setContextClassLoader(ClassLoader loader)
    {
        loaderReference = loader != null ? new WeakReference<ClassLoader>(loader) : null;
    }
}
