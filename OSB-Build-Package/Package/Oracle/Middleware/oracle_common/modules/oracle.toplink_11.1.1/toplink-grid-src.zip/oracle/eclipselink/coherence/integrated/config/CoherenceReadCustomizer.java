// Copyright (c) 1998, 2011, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.config;

import oracle.eclipselink.coherence.integrated.cache.CoherenceInterceptor;
import oracle.eclipselink.coherence.integrated.querying.ReadAllFromCoherence;
import oracle.eclipselink.coherence.integrated.querying.ReadObjectFromCoherence;
import oracle.eclipselink.coherence.integrated.querying.ReadObjectFromCoherence;
import oracle.eclipselink.coherence.integrated.querying.ReportQueryFromCoherence;

import org.eclipse.persistence.config.DescriptorCustomizer;
import org.eclipse.persistence.descriptors.ClassDescriptor;

/**
 * This class should be set on an Entity that will be stored within Coherence
 * and whose read queries should retrieve entities from Coherence. This
 * customizer can be set through native code, annotations or xml
 * (persistence.xml)
 * 
 * @see org.eclipse.persistence.annotations.Customizer To change the default
 *      behaviour of this configuration the user can add or remove
 *      QueryRedirectors to control the entity operation/query specific
 *      behaviour.
 * 
 * @see org.eclipse.persistence.annotaitons.QueryRedirectors
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class CoherenceReadCustomizer implements DescriptorCustomizer {

    public void customize(ClassDescriptor descriptor) throws Exception {
        descriptor.setCacheInterceptorClass(CoherenceInterceptor.class);
        descriptor.setDefaultReadAllQueryRedirector(new ReadAllFromCoherence());
        descriptor.setDefaultReadObjectQueryRedirector(new ReadObjectFromCoherence());
        descriptor.setDefaultReportQueryRedirector(new ReportQueryFromCoherence());
        descriptor.setFullyMergeEntity(true);

    }
    
    public static void afterLoad(ClassDescriptor descriptor){
        descriptor.setCacheInterceptorClass(CoherenceInterceptor.class);
        descriptor.setDefaultReadAllQueryRedirector(new ReadAllFromCoherence());
        descriptor.setDefaultReadObjectQueryRedirector(new ReadObjectFromCoherence());
        descriptor.setDefaultReportQueryRedirector(new ReportQueryFromCoherence());
        descriptor.setFullyMergeEntity(true);
    }

}
