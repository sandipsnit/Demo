// Copyright (c) 1998, 2011, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.cache;

import static org.eclipse.persistence.logging.SessionLog.CACHE;
import static org.eclipse.persistence.logging.SessionLog.FINE;
import static org.eclipse.persistence.logging.SessionLog.FINER;

import java.lang.reflect.Constructor;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import oracle.eclipselink.coherence.IntegrationProperties;
import oracle.eclipselink.coherence.exceptions.IntegrationException;
import oracle.eclipselink.coherence.integrated.cache.CoherenceInterceptor;
import oracle.eclipselink.coherence.integrated.cache.Wrapper;
import oracle.eclipselink.coherence.integrated.internal.InternalProperties;
import oracle.eclipselink.coherence.integrated.internal.querying.FilterExtractor;

import org.eclipse.persistence.annotations.CacheKeyType;
import org.eclipse.persistence.descriptors.CMPPolicy;
import org.eclipse.persistence.descriptors.ClassDescriptor;
import org.eclipse.persistence.descriptors.VersionLockingPolicy;
import org.eclipse.persistence.exceptions.OptimisticLockException;
import org.eclipse.persistence.indirection.ValueHolder;
import org.eclipse.persistence.internal.descriptors.ObjectBuilder;
import org.eclipse.persistence.internal.helper.DatabaseField;
import org.eclipse.persistence.internal.identitymaps.CacheId;
import org.eclipse.persistence.internal.indirection.CacheBasedValueHolder;
import org.eclipse.persistence.internal.indirection.DatabaseValueHolder;
import org.eclipse.persistence.internal.indirection.IndirectionPolicy;
import org.eclipse.persistence.internal.jpa.CMP3Policy;
import org.eclipse.persistence.internal.queries.ContainerPolicy;
import org.eclipse.persistence.internal.queries.MappedKeyMapContainerPolicy;
import org.eclipse.persistence.internal.security.PrivilegedAccessHelper;
import org.eclipse.persistence.internal.security.PrivilegedClassForName;
import org.eclipse.persistence.internal.security.PrivilegedGetConstructorFor;
import org.eclipse.persistence.internal.security.PrivilegedInvokeConstructor;
import org.eclipse.persistence.internal.security.PrivilegedNewInstanceFromClass;
import org.eclipse.persistence.internal.sessions.AbstractRecord;
import org.eclipse.persistence.internal.sessions.AbstractSession;
import org.eclipse.persistence.mappings.AggregateCollectionMapping;
import org.eclipse.persistence.mappings.AttributeAccessor;
import org.eclipse.persistence.mappings.CollectionMapping;
import org.eclipse.persistence.mappings.DatabaseMapping;
import org.eclipse.persistence.mappings.DirectCollectionMapping;
import org.eclipse.persistence.mappings.ForeignReferenceMapping;
import org.eclipse.persistence.mappings.ManyToManyMapping;
import org.eclipse.persistence.mappings.ObjectReferenceMapping;
import org.eclipse.persistence.mappings.OneToManyMapping;
import org.eclipse.persistence.mappings.TransformationMapping;
import org.eclipse.persistence.queries.DeleteObjectQuery;
import org.eclipse.persistence.queries.ObjectBuildingQuery;
import org.eclipse.persistence.queries.UpdateObjectQuery;
import org.eclipse.persistence.sessions.DatabaseRecord;
import org.eclipse.persistence.sessions.Session;

import com.tangosol.net.NamedCache;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.InvocableMap.EntryProcessor;
import com.tangosol.util.extractor.AbstractExtractor;

/**
 * <p>
 * <b>Purpose:</b> This class contains a collection of functionality that is
 * used internally by the integration.
 * 
 * @author gyorke, djclarke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */

public abstract class CoherenceCacheHelper {

    protected static final ThreadLocal<ComposeIdentityMap> composeIdentityMap = new ThreadLocal<ComposeIdentityMap>();

    protected static CoherenceAdaptor coherenceAdaptor;

    public static Object composeStub(ForeignReferenceMapping mapping, Object referencePKs, AbstractSession session) {
        // build a stub for insert
        if (referencePKs == null) {
            return null;
        }
        Object newObject = null;
        ObjectBuilder builder = mapping.getReferenceDescriptor().getObjectBuilder();
        ObjectBuildingQuery clonedQuery = (ObjectBuildingQuery) (mapping).getSelectionQuery().clone();
        clonedQuery.setSession(session);
        newObject = mapping.getReferenceDescriptor().getInstantiationPolicy().buildNewInstance();
        builder.buildPrimaryKeyAttributesIntoObject(newObject, builder.buildRowFromPrimaryKeyValues(referencePKs, session), clonedQuery, session);
        return newObject;
    }

    public static Object getFromCoherence(ClassDescriptor descriptor, AbstractSession interceptedSession, NamedCache namedCache, Object cacheId, boolean shouldTranslatePKs) {
        Object cohKey = getCoherenceKey(descriptor, cacheId, interceptedSession, shouldTranslatePKs);
        return getFromCoherenceWithCohKey(descriptor, interceptedSession, namedCache, cohKey, shouldTranslatePKs);
    }

    public static Map<Object, Object> getAllFromCoherenceWithCohKey(Object[] pkList, ClassDescriptor descriptor, AbstractSession interceptedSession, NamedCache namedCache, boolean shouldTranslatePKs) {

        if (shouldTranslatePKs && descriptor.hasCMPPolicy() && descriptor.getCacheKeyType() == CacheKeyType.CACHE_ID) {
            pkList = translateToCoherencePKs(pkList, null, descriptor.getCMPPolicy(), interceptedSession);
        }
        // let's hit coherence for this object
        if (interceptedSession.shouldLog(FINER, CACHE)) {
            interceptedSession.log(FINER, CACHE, "Coherence(" + namedCache.getCacheName() + ")::GetAll: " + pkList, (Object[]) null, null, false);
        }
        Map<Object, Object> gridEntities = namedCache.getAll(Arrays.asList(pkList));
        Map<Object, Object> result = new HashMap<Object, Object>(gridEntities.size());

        for (Map.Entry<Object, Object> entry : gridEntities.entrySet()) {

            Object cachedObject = null;
            ComposeIdentityMap cim = composeIdentityMap.get();
            if (cim != null) {
                cachedObject = cim.getComposedEntity(descriptor.getJavaClass(), entry.getKey());
            }
            if (cachedObject == null) {
                cachedObject = composeEntity(entry.getKey(), entry.getValue(), descriptor, interceptedSession, false, shouldTranslatePKs);
            }
            result.put(entry.getKey(), cachedObject);
        }
        if (interceptedSession.shouldLog(FINE, CACHE)) {
            interceptedSession.log(FINE, CACHE, "Coherence(" + namedCache.getCacheName() + ")::Get: " + pkList + " result: " + result, (Object[]) null, null, false);
        }
        return result;
    }

    public static Object getFromCoherenceWithCohKey(ClassDescriptor descriptor, AbstractSession interceptedSession, NamedCache namedCache, Object cohKey, boolean shouldTranslatePKs) {
        Object cachedObject = null;
        ComposeIdentityMap cim = composeIdentityMap.get();
        if (cim != null) {
            cachedObject = cim.getComposedEntity(descriptor.getJavaClass(), cohKey);
            if (cachedObject != null) {
                return cachedObject;
            }
        }

        // let's hit coherence for this object
        if (interceptedSession.shouldLog(FINER, CACHE)) {
            interceptedSession.log(FINER, CACHE, "Coherence(" + namedCache.getCacheName() + ")::Get: " + cohKey, (Object[]) null, null, false);
        }
        cachedObject = namedCache.get(cohKey);
        cachedObject = composeEntity(cohKey, cachedObject, descriptor, interceptedSession, false, shouldTranslatePKs);

        if (interceptedSession.shouldLog(FINE, CACHE)) {
            interceptedSession.log(FINE, CACHE, "Coherence(" + namedCache.getCacheName() + ")::Get: " + cohKey + " result: " + cachedObject, (Object[]) null, null, false);
        }
        return cachedObject;
    }

    private static void createCacheIndex(DatabaseMapping mapping, NamedCache cache, ClassDescriptor descriptor, Session session) {
        ValueExtractor extractor = new FilterExtractor(mapping);
        cache.addIndex(extractor, false, null);
    }

    public static EntryProcessor createConditionalPutForOptLocking(ClassDescriptor descriptor, VersionLockingPolicy policy, Object original, Object objectToPut) {
        Object writeLockValue = policy.getWriteLockValue(original, null, null);
        AbstractExtractor extractor = new FilterExtractor(policy.getVersionMapping());
        return new VersionPutProcessor(writeLockValue, extractor, objectToPut, true);
    }

    public static EntryProcessor createConditionalPutWithOptLocking(ClassDescriptor descriptor, VersionLockingPolicy policy, Object original, Object objectToPut) {
        Object writeLockValue = policy.getWriteLockValue(original, null, null);
        AbstractExtractor extractor = new FilterExtractor(policy.getVersionMapping());
        return new VersionPutProcessor(writeLockValue, extractor, objectToPut, false);
    }

    public static EntryProcessor createConditionalRemoveForOptLocking(ClassDescriptor descriptor, VersionLockingPolicy policy, Object original) {
        Object writeLockValue = policy.getWriteLockValue(original, null, null);
        return new VersionRemoveProcessor(writeLockValue, new FilterExtractor(policy.getVersionMapping()));
    }

    /**
     * Helper method that determines if a provided descriptor is configured with
     * a CoherenceInterceptor.
     */
    public static boolean usesCoherenceInterceptor(ClassDescriptor descriptor) {
        return (descriptor.getCacheInterceptorClass() != null && descriptor.getCacheInterceptorClass() == CoherenceInterceptor.class) || (descriptor.getCacheInterceptorClassName() != null && descriptor.getCacheInterceptorClassName().equals(CoherenceInterceptor.class.getName()));
    }

    /**
     * This method is used to notify coherence that a relationship has been
     * updated.
     */
    public static void updateRelationship(ClassDescriptor descriptor, AbstractSession interceptedSession, NamedCache namedCache, Object primaryKey, Object attributeValue, Object original, ForeignReferenceMapping mapping, boolean translatePKs) {
        Object versionValue = null;
        AbstractExtractor extractor = null;
        VersionLockingPolicy policy = (VersionLockingPolicy) descriptor.getOptimisticLockingPolicy();
        if (policy != null) {
            versionValue = policy.getWriteLockValue(original, primaryKey, interceptedSession);
            extractor = new FilterExtractor(policy.getVersionMapping());

        }
        EntryProcessor processor;
        if (mapping.isElementCollectionMapping()) {
            AttributeAccessor attributeAccessor = mapping.getAttributeAccessor();
            processor = new ElementCollectionUpdateProcessor(attributeValue, attributeAccessor, versionValue, extractor);
        } else {
            Object[] references = mapping.buildReferencesPKList(original, attributeValue, interceptedSession);
            if (translatePKs){
                ClassDescriptor referenceDescriptor = mapping.getReferenceDescriptor();
                if (referenceDescriptor.hasCMPPolicy() && referenceDescriptor.getCacheKeyType() == CacheKeyType.CACHE_ID) {
                    references = translateToCoherencePKs(references, null, referenceDescriptor.getCMPPolicy(), interceptedSession);
                }
            }
            processor = new RelationshipUpdateProcessor(references, mapping.getAttributeName(), versionValue, extractor);
        }
        namedCache.invoke(getCoherenceKey(descriptor, primaryKey, interceptedSession, translatePKs), processor);
    }

    /**
     * Helper method to retrieve the cache name to use for the provided
     * descriptor. The name is either provided using a descriptor property or if
     * that is not provided then the descriptor's alias is used. In JPA a
     * descriptor's alias is the entity's name defaulted to be the unqualified
     * class name.
     * 
     * @see InternalProperties.CACHE_NAME
     */
    public static String getCacheName(ClassDescriptor descriptor) {
        String property = (String) descriptor.getProperty(IntegrationProperties.COHERENCE_CACHE_NAME);
        if (property == null) {
            property = (String) descriptor.getProperty(IntegrationProperties.CACHE_NAME);
            if (property == null) {
                String defaultName = descriptor.getAlias();
                return defaultName == null ? descriptor.getJavaClassName() : defaultName;
            }
        }
        return property;
    }

    /**
     * Helper method to determine that wrapper class name that will be used
     * within the Coherence cache.
     * 
     * @param javaClassName
     *            fully qualified java class name including package.
     * @return
     */
    public static String getWrapperClassName(Class javaClass) {
        return getWrapperClassName(javaClass.getName());
    }

    /**
     * Helper method to determine that wrapper class name that will be used
     * within the Coherence cache.
     * 
     * @param javaClassName
     *            fully qualified java class name including package.
     * @return
     */
    public static String getWrapperClassName(String javaClassName) {
        return "oracle.eclipselink.coherence.integrated.cache.wrappers." + javaClassName + "_Wrapper";
    }

    /**
     * Lookup the Coherence NamedCache for a provided descriptor.
     * 
     * @param descriptor
     * @param session
     *            used to access the default class-loader for the lookup
     * @return
     */
    public static NamedCache getNamedCache(ClassDescriptor descriptor, Session session) {
        if (descriptor.hasInheritance()) {
            descriptor = descriptor.getInheritancePolicy().getRootParentDescriptor();
        }
        NamedCache cache = null;
        if (CoherenceCacheHelper.coherenceAdaptor == null) {
            try {
                Class adaptorClass = Class.forName("oracle.eclipselink.coherence.integrated.internal.cache.Coherence35Adaptor");
                if (PrivilegedAccessHelper.shouldUsePrivilegedAccess()) {
                    Constructor constructor = (Constructor) AccessController.doPrivileged(new PrivilegedGetConstructorFor(adaptorClass, new Class[0], true));
                    CoherenceCacheHelper.coherenceAdaptor = (CoherenceAdaptor) AccessController.doPrivileged(new PrivilegedInvokeConstructor(constructor, new Object[0]));
                } else {
                    Constructor constructor = PrivilegedAccessHelper.getDeclaredConstructorFor(adaptorClass, new Class[0], true);
                    CoherenceCacheHelper.coherenceAdaptor = (CoherenceAdaptor) PrivilegedAccessHelper.invokeConstructor(constructor, new Object[0]);
                }
            } catch (Exception exception) {
                CoherenceCacheHelper.coherenceAdaptor = new CoherenceAdaptor();
            }
        }
        cache = CoherenceCacheHelper.coherenceAdaptor.getNamedCache(descriptor, session);
        initializeForDescriptor(descriptor, cache, session);
        return cache;
    }

    /**
     * Lookup in the provided session a ClassDescriptor which is configured to
     * use the provided cache name. This lookup involves matching either the
     * cache name provided in a descriptor property or the descriptor's alias as
     * well as ensuring that a CoherenceInterceptor is configured on the
     * descriptor if the requiresCacheInterceptor param is true.
     * <p>
     * This method is used to initialize the descriptor used in the standalone
     * and integrated CacheLoader/Store implementations.
     * 
     * @param cacheName
     *            Provided Coherence NamedCache name
     * @param session
     *            the EclipseLink session in which to lookup the descriptor
     * @param requiresCacheInterceptor
     *            indicating if the descriptor must have a CoherenceInterceptor
     *            configured
     * @return Descriptor configured to use provided Coherence cache name
     * @throws IntegrationException
     *             if no descriptor is configured to use the provided cache name
     * @see IntegrationException#UNABLE_TO_FIND_DESCRIPTOR
     */
    public static ClassDescriptor getDescriptor(String cacheName, Session session, boolean requiresCacheInterceptor) {
        Iterator iter = session.getDescriptors().values().iterator();

        while (iter.hasNext()) {
            ClassDescriptor desc = (ClassDescriptor) iter.next();

            if (cacheName.equals(getCacheName(desc))) {
                if (requiresCacheInterceptor) {
                    if (usesCoherenceInterceptor(desc)) {
                        return desc;
                    }
                } else {
                    return desc;
                }
            }
        }

        throw IntegrationException.unableToFindDescriptor(cacheName, session);
    }

    public static NamedCache getNamedCache(Class entityClass, Session session) {
        ClassDescriptor descriptor = session.getClassDescriptor(entityClass);

        if (descriptor == null) {
            throw new IllegalArgumentException("No descriptor found for class: " + entityClass);
        }
        return getNamedCache(descriptor, session);
    }

    public static void initializeForDescriptor(ClassDescriptor descriptor, NamedCache cache, Session session) {
        if (descriptor.hasInheritance() && descriptor.getInheritancePolicy().isRootParentDescriptor()) {
            for (ClassDescriptor childDesc : descriptor.getInheritancePolicy().getChildDescriptors()) {
                initializeForDescriptor(childDesc, cache, session);
            }
        }
        if (descriptor.getProperty(InternalProperties.DESCRIPTOR_INITIALIZED) == null) {
            // let's make sure we have the wrapper defined:
            defineWrapperClass(descriptor, session.getPlatform().getConversionManager().getLoader());
            // next create any requested Coherence Cache indexes
            for (DatabaseMapping mapping : descriptor.getMappings()) {
                if (mapping.getProperty(IntegrationProperties.INDEXED) != null) {
                    createCacheIndex(mapping, cache, descriptor, session);
                }
            }
            descriptor.setProperty(InternalProperties.DESCRIPTOR_INITIALIZED, Boolean.TRUE);
        }
    }

    public static void putIntoCoherence(ClassDescriptor descriptor, AbstractSession interceptedSession, NamedCache namedCache, Object key, Object original, boolean forRead, boolean translatePKs) {
        if (descriptor.hasInheritance() && !original.getClass().equals(descriptor.getJavaClass())) {
            descriptor = interceptedSession.getDescriptor(original);
        }
        Object cohKey = getCoherenceKey(descriptor, key, interceptedSession, translatePKs);
        Object objectToPut = decomposeEntity(original, descriptor, interceptedSession, translatePKs);

        if (descriptor.getOptimisticLockingPolicy() != null) {
            if (interceptedSession.shouldLog(FINE, CACHE)) {
                interceptedSession.log(FINE, CACHE, "Coherence(" + namedCache.getCacheName() + ")::ConditionalPut: " + cohKey + " value: " + original, (Object[]) null, null, false);
            }
            objectToPut = namedCache.getCacheService().getBackingMapManager().getContext().getValueToInternalConverter().convert(objectToPut);
            EntryProcessor condPut = null;
            if (descriptor.getDefaultInsertObjectQueryRedirector() != null && !forRead) {
                condPut = CoherenceCacheHelper.createConditionalPutForOptLocking(descriptor, (VersionLockingPolicy) descriptor.getOptimisticLockingPolicy(), original, objectToPut);
                // if there is a optimistic lock policy update the version
                // number here:
            } else {
                condPut = CoherenceCacheHelper.createConditionalPutWithOptLocking(descriptor, (VersionLockingPolicy) descriptor.getOptimisticLockingPolicy(), original, objectToPut);
            }
            Object result = namedCache.invoke(cohKey, condPut);
            if (result != null) {
                UpdateObjectQuery query = new UpdateObjectQuery();
                query.setSession(interceptedSession);
                throw OptimisticLockException.objectChangedSinceLastReadWhenUpdating(original, query);
            }
        } else {
            if (interceptedSession.shouldLog(FINE, CACHE)) {
                interceptedSession.log(FINE, CACHE, "Coherence(" + namedCache.getCacheName() + ")::Put: " + cohKey + " value: " + original, (Object[]) null, null, false);
            }
            Map putMap = new HashMap();
            putMap.put(cohKey, objectToPut);
            namedCache.putAll(putMap);
        }
    }

    public static Object composeEntity(Object key, Object object, ClassDescriptor descriptor, AbstractSession session, boolean inCacheStore, boolean shouldTranslatePKs) {
        if (object == null) {
            return null;
        }
        if (!(object instanceof Wrapper)) {
            return object;
        }
        Wrapper cacheWrapper = (Wrapper) object;
        Object entity = cacheWrapper.unwrap();

        if (descriptor.hasInheritance() && !entity.getClass().equals(descriptor.getJavaClass())) {
            descriptor = session.getDescriptor(entity);
        }
        for (Iterator<DatabaseMapping> mappings = descriptor.getMappings().iterator(); mappings.hasNext();) {
            DatabaseMapping mapping = mappings.next();
            if (mapping.isForeignReferenceMapping()) {
                Object[] referencePKs = cacheWrapper.getPrimaryKeyValuesFor(mapping.getAttributeName());
                IndirectionPolicy ip = ((ForeignReferenceMapping) mapping).getIndirectionPolicy();
                Object vh = null;
                boolean shouldUpdateRelationship = false;
                if (ip.usesIndirection()) {
                    if (!(ip.getOriginalValueHolder(mapping.getAttributeValueFromObject(entity), session) instanceof ValueHolder)){
                        continue;
                    }
                    if (referencePKs == null) {
                        // indirection has not yet been triggered
                        Object[] row = cacheWrapper.getForeignKeyValuesFor(mapping.getAttributeName());
                        if (row == null){
                            if (((ForeignReferenceMapping) mapping).getIndirectionPolicy().usesTransparentIndirection()){
                                if (mapping.isElementCollectionMapping()) {
                                    if (((ForeignReferenceMapping) mapping).getContainerPolicy().isListPolicy()){
                                        //EclipseLink does not support non Vector in combination with Transparent indirection so we must clone the collection
                                        //if the user has used another type.
                                        Vector newVector = new Vector((List)mapping.getRealAttributeValueFromObject(entity, session));
                                        mapping.setRealAttributeValueInObject(entity, newVector);
                                    }
                                } else {
                                    //replace custom user collection classes that may have been set by POF.
                                    mapping.setRealAttributeValueInObject(entity, ((ForeignReferenceMapping) mapping).getContainerPolicy().containerInstance());
                                }
                            }
                            continue;
                        }
                        vh = ip.valueFromQuery(((ForeignReferenceMapping) mapping).getSelectionQuery(), composeDatabaseRecord(row), entity, session);
                    } else {
                        if (shouldTranslatePKs && mapping.getReferenceDescriptor().hasCMPPolicy() && mapping.getReferenceDescriptor().getCacheKeyType() == CacheKeyType.CACHE_ID) {
                            referencePKs = translateToEclipseLinkPKs(referencePKs, (ForeignReferenceMapping) mapping, mapping.getReferenceDescriptor().getCMPPolicy(), session);
                        }
                        CacheBasedValueHolder cbvh = new CacheBasedValueHolder(referencePKs, session, ((ForeignReferenceMapping) mapping));
                        cbvh.setShouldAllowInstantiationDeferral(false);
                        vh = ip.buildIndirectObject(cbvh);
                        if (inCacheStore) { // set stubs in the relationship for merge.
                            if (mapping.isObjectReferenceMapping()) {
                                if ( referencePKs.length > 0){
                                    cbvh.setValue(CoherenceCacheHelper.composeStub((ForeignReferenceMapping) mapping, referencePKs[0], session));
                                }else{
                                    cbvh.setValue(null);
                                }
                            } else {
                                ContainerPolicy cp = mapping.getContainerPolicy();
                                if (cp.isMapPolicy()) {
                                    Object container = cp.containerInstance();
                                    for (int index = 0; index < referencePKs.length; ++index) {
                                        Object entryKey = referencePKs[index];
                                        ++index;
                                        if (cp.isMappedKeyMapPolicy()) {
                                            entryKey = ((MappedKeyMapContainerPolicy) cp).getKeyMapping().createStubbedMapComponentFromSerializableKeyInfo(entryKey, session);
                                        }
                                        cp.addInto(entryKey, CoherenceCacheHelper.composeStub((ForeignReferenceMapping) mapping, referencePKs[index], session), container, session);
                                    }
                                    cbvh.setValue(container);
                                } else {
                                    Vector values = new Vector();
                                    for (Object pks : referencePKs) {
                                        values.add(CoherenceCacheHelper.composeStub((ForeignReferenceMapping) mapping, pks, session));
                                    }
                                    cbvh.setValue(((CollectionMapping) mapping).getContainerPolicy().buildContainerFromVector(values, session));
                                }
                            }
                        }
                    }
                } else {
                    if (mapping.getAttributeValueFromObject(entity) != null){
                        continue;
                    }

                    if (referencePKs != null) {
                        if (shouldTranslatePKs && mapping.getReferenceDescriptor().hasCMPPolicy() && mapping.getReferenceDescriptor().getCacheKeyType() == CacheKeyType.CACHE_ID) {
                            referencePKs = translateToEclipseLinkPKs(referencePKs, (ForeignReferenceMapping) mapping, mapping.getReferenceDescriptor().getCMPPolicy(), session);
                        }
                        ComposeIdentityMap cim = composeIdentityMap.get();
                        if (cim == null) {
                            cim = new ComposeIdentityMap();
                            composeIdentityMap.set(cim);
                        }
                        cim.incrementDepth();
                        cim.addComposedEntity(key, entity);
                        try {
                            if (inCacheStore){ //set stubs in the relationship for merge.
                                if (mapping.isObjectReferenceMapping()) {
                                    vh = CoherenceCacheHelper.composeStub((ForeignReferenceMapping) mapping, referencePKs[0], session);
                                } else {
                                    Vector values = new Vector();
                                    for (Object pks : referencePKs) {
                                        values.add(CoherenceCacheHelper.composeStub((ForeignReferenceMapping) mapping, pks, session));
                                    }
                                    vh = ((CollectionMapping) mapping).getContainerPolicy().buildContainerFromVector(values, session);
                                }
                            } else {
                                // must go to parent of UOW because we are composing an entity.  If we use a UOW and we are in a cycle then
                                //this entity will be registered before it is fully built.
                                //We could go directly to Coherence for composing relationships but that would not work for object loaded by
                                //EclipseLink
                                AbstractSession querySession = session;
                                while (querySession.isUnitOfWork()) {
                                    querySession = querySession.getParent();
                                }
                                vh = new CacheBasedValueHolder(referencePKs, querySession, ((ForeignReferenceMapping) mapping)).getValue();
                            }
                        } finally {
                            cim.decrementDepth();
                            if (cim.atStart()) {
                                composeIdentityMap.set(null);
                            }
                        }
                    } else {
                        Object[] row = cacheWrapper.getForeignKeyValuesFor(mapping.getAttributeName());
                        if (row != null) {
                            // the wrapper has non triggered indirection for the mapping that does not use indirection
                            ComposeIdentityMap cim = composeIdentityMap.get();
                            if (cim == null) {
                                cim = new ComposeIdentityMap();
                                composeIdentityMap.set(cim);
                            }
                            cim.incrementDepth();
                            cim.addComposedEntity(key, entity);
                            try {
                                // must go to parent of UOW because we are composing an entity.  If we use a UOW and we are in a cycle then
                                //this entity will be registered before it is fully built.
                                //We could go directly to Coherence for composing relationships but that would not work for object loaded by
                                //EclipseLink
                                AbstractSession querySession = session;
                                while (querySession.isUnitOfWork()) {
                                    querySession = querySession.getParent();
                                }
                                vh = session.executeQuery(((ForeignReferenceMapping) mapping).getSelectionQuery(), composeDatabaseRecord(row));
                            } finally {
                                cim.decrementDepth();
                                if (cim.atStart()) {
                                    composeIdentityMap.set(null);
                                }
                            }
                            // can't update relationship if called from cache store 
                            shouldUpdateRelationship = !inCacheStore;
                        }
                        // if referencePKs is null and row is null set null
                    }
                }
                mapping.setAttributeValueInObject(entity, vh);
                if (shouldUpdateRelationship) {
                    updateRelationship(descriptor, session, getNamedCache(descriptor, session), key, vh, entity, (ForeignReferenceMapping)mapping, shouldTranslatePKs);
                }
            }
            if (mapping.isTransformationMapping()) {
                Object[] record = cacheWrapper.getForeignKeyValuesFor(mapping.getAttributeName());
                if (record != null) {
                    IndirectionPolicy ip = ((TransformationMapping) mapping).getIndirectionPolicy();
                    // untriggered indirection
                    mapping.setAttributeValueInObject(entity, ip.valueFromMethod(entity, composeDatabaseRecord(record), session));
                }
            }
        }
        return entity;
    }

    public static Object decomposeEntity(Object entity, ClassDescriptor descriptor, AbstractSession session, boolean translatePKs) {
        if (descriptor.hasInheritance() && !entity.getClass().equals(descriptor.getJavaClass())) {
            descriptor = session.getDescriptor(entity);
        }
        Wrapper cacheWrapper = createEntityWrapper(descriptor, entity.getClass().getClassLoader());
        Object wrappedEntity = descriptor.getObjectBuilder().buildNewInstance();
        cacheWrapper.wrap(wrappedEntity);
        boolean hasNoForeignKeyMapping = true;
        for (Iterator<DatabaseMapping> mappings = descriptor.getMappings().iterator(); mappings.hasNext();) {
            DatabaseMapping mapping = mappings.next();
            if (mapping.isOneToManyMapping() || mapping.isObjectReferenceMapping() || mapping.isManyToManyMapping()) {
                hasNoForeignKeyMapping = false;
                Object[] references = null;
                IndirectionPolicy ip = ((ForeignReferenceMapping) mapping).getIndirectionPolicy();
                Object attributeValue = mapping.getAttributeValueFromObject(entity);
                if (attributeValue == null) {
                    continue;
                }
                if (ip.usesIndirection()) {
                    Object vh = ip.getOriginalValueHolder(attributeValue, session);
                    if (ip.objectIsInstantiated(attributeValue)) {
                        references = ((ForeignReferenceMapping) mapping).buildReferencesPKList(entity, attributeValue, session);
                        if (translatePKs && mapping.getReferenceDescriptor().hasCMPPolicy() && mapping.getReferenceDescriptor().getCacheKeyType() == CacheKeyType.CACHE_ID) {
                            references = translateToCoherencePKs(references, (ForeignReferenceMapping) mapping, mapping.getReferenceDescriptor().getCMPPolicy(), session);
                        }
                        cacheWrapper.setPrimaryKeyValuesFor(mapping.getAttributeName(), references);
                    } else if (vh instanceof CacheBasedValueHolder) {
                        references = ((CacheBasedValueHolder) vh).getCachedPKs();
                        if (translatePKs && mapping.getReferenceDescriptor().hasCMPPolicy() && mapping.getReferenceDescriptor().getCacheKeyType() == CacheKeyType.CACHE_ID) {
                            references = translateToCoherencePKs(references, (ForeignReferenceMapping) mapping, mapping.getReferenceDescriptor().getCMPPolicy(), session);
                        }
                        cacheWrapper.setPrimaryKeyValuesFor(mapping.getAttributeName(), references);
                    } else if (vh instanceof DatabaseValueHolder) {
                        cacheWrapper.setForeignKeyValuesFor(mapping.getAttributeName(), decomposeDatabaseRecord(((DatabaseValueHolder) vh).getRow(), getKeyFields(mapping)));
                    }
                    mapping.setAttributeValueInObject(wrappedEntity, ip.buildIndirectObject(new ValueHolder()));
                } else {
                    references = ((ForeignReferenceMapping) mapping).buildReferencesPKList(entity, attributeValue, session);
                    if (translatePKs && mapping.getReferenceDescriptor().hasCMPPolicy() && mapping.getReferenceDescriptor().getCacheKeyType() == CacheKeyType.CACHE_ID) {
                        references = translateToCoherencePKs(references, (ForeignReferenceMapping) mapping, mapping.getReferenceDescriptor().getCMPPolicy(), session);
                    }
                    cacheWrapper.setPrimaryKeyValuesFor(mapping.getAttributeName(), references);
                    mapping.setAttributeValueInObject(wrappedEntity, null);
                }
            } else if (mapping.isElementCollectionMapping()) {
                Object[] references = null;
                IndirectionPolicy ip = ((ForeignReferenceMapping) mapping).getIndirectionPolicy();
                Object attributeValue = mapping.getAttributeValueFromObject(entity);
                if (attributeValue == null) {
                    continue;
                }
                if (ip.usesIndirection()) {
                    hasNoForeignKeyMapping = false;
                    Object vh = ip.getOriginalValueHolder(attributeValue, session);
                    if (!ip.objectIsInstantiated(attributeValue)) {
                        if (vh instanceof DatabaseValueHolder) {
                            Vector[] row = new Vector[2];
                            row[0] = ((DatabaseValueHolder) vh).getRow().getFields();
                            row[1] = ((DatabaseValueHolder) vh).getRow().getValues();
                            cacheWrapper.setForeignKeyValuesFor(mapping.getAttributeName(), decomposeDatabaseRecord(((DatabaseValueHolder) vh).getRow(), getKeyFields(mapping)));
                            mapping.setAttributeValueInObject(wrappedEntity, ip.buildIndirectObject(new ValueHolder()));
                        } else {
                            // Indirection not transferable. Must instantiate.
                            ip.instantiateObject(entity, attributeValue);
                            mapping.setAttributeValueInObject(wrappedEntity, attributeValue);
                        }
                    } else {
                        mapping.setAttributeValueInObject(wrappedEntity, mapping.getAttributeValueFromObject(entity));
                    }
                } else {
                    mapping.setAttributeValueInObject(wrappedEntity, mapping.getAttributeValueFromObject(entity));
                }
            } else if (mapping.isTransformationMapping()) {
                IndirectionPolicy ip = ((TransformationMapping) mapping).getIndirectionPolicy();
                Object attributeValue = mapping.getAttributeValueFromObject(entity);
                if (!ip.objectIsInstantiated(mapping.getAttributeValueFromObject(entity))) {
                    cacheWrapper.setForeignKeyValuesFor(mapping.getAttributeName(), decomposeDatabaseRecord(((DatabaseValueHolder) ip.getOriginalValueHolder(attributeValue, session)).getRow(), getKeyFields(mapping)));
                } else {
                    mapping.setAttributeValueInObject(wrappedEntity, mapping.getAttributeValueFromObject(entity));
                }
            } else {
                mapping.setRealAttributeValueInObject(wrappedEntity, mapping.getRealAttributeValueFromObject(entity, session));
            }
        }
        if (hasNoForeignKeyMapping) {
            return entity;
        }
        return cacheWrapper;
    }

    /**
     * defines a wrapper class if not already defined
     * 
     * @param descriptor
     * @param classLoader
     * @return wrapper class
     */
    public static Class defineWrapperClass(ClassDescriptor descriptor, ClassLoader classLoader) {
        Class wrapperClass = (Class) descriptor.getProperty(InternalProperties.CACHE_WRAPPER);
        if (wrapperClass == null) {
            synchronized (descriptor) {
                wrapperClass = defineWrapperClass(descriptor.getJavaClass(), classLoader);
                descriptor.setProperty(InternalProperties.CACHE_WRAPPER, wrapperClass);
            }
        }
        return wrapperClass;

    }

    /**
     * defines a wrapper class if not already defined
     * 
     * @param wrappedClass
     * @param classLoader
     * @return wrapper class
     */
    public static Class defineWrapperClass(Class wrappedClass, ClassLoader classLoader) {
        // let's see if it's already loaded
        Class wrapperClass = null;
        try {
            if (PrivilegedAccessHelper.shouldUsePrivilegedAccess()) {
                try {
                    wrapperClass = (Class) AccessController.doPrivileged(new PrivilegedClassForName(getWrapperClassName(wrappedClass), true, classLoader));
                    return wrapperClass;
                } catch (PrivilegedActionException exception) {
                    // ignore - probably have not created it yet
                }
            } else {
                wrapperClass = org.eclipse.persistence.internal.security.PrivilegedAccessHelper.getClassForName(getWrapperClassName(wrappedClass), true, classLoader);
                return wrapperClass;
            }
        } catch (ClassNotFoundException ex) {
            // ignore - probably have not created it yet
        }

        if (wrapperClass == null) {
            // have not yet defined class
            WrapperGenerator generator = new WrapperGenerator();
            generator.createWrapperFor(wrappedClass, classLoader);
            try {
                if (PrivilegedAccessHelper.shouldUsePrivilegedAccess()) {
                    try {
                        wrapperClass = (Class) AccessController.doPrivileged(new PrivilegedClassForName(getWrapperClassName(wrappedClass), true, classLoader));
                    } catch (PrivilegedActionException exception) {
                        throw IntegrationException.failedToLoadWrapperClass(getWrapperClassName(wrappedClass), exception.getException());
                    }
                } else {
                    wrapperClass = org.eclipse.persistence.internal.security.PrivilegedAccessHelper.getClassForName(getWrapperClassName(wrappedClass), true, classLoader);
                }
            } catch (ClassNotFoundException exc) {
                throw IntegrationException.failedToLoadWrapperClass(getWrapperClassName(wrappedClass), exc);
            }

        }
        return wrapperClass;
    }

    public static Wrapper createEntityWrapper(ClassDescriptor descriptor, ClassLoader classLoader) {
        return createEntityWrapper(defineWrapperClass(descriptor, classLoader));
    }

    public static Wrapper createEntityWrapper(Class wrapperClass) {
        Wrapper wrapperInstance = null;
        try {
            if (PrivilegedAccessHelper.shouldUsePrivilegedAccess()) {
                try {
                    wrapperInstance = (Wrapper) AccessController.doPrivileged(new PrivilegedNewInstanceFromClass(wrapperClass));
                } catch (PrivilegedActionException exc) {
                    IntegrationException.failedToCreateWrapperInstance(wrapperClass.getName(), exc);
                }
            } else {
                wrapperInstance = (Wrapper) org.eclipse.persistence.internal.security.PrivilegedAccessHelper.newInstanceFromClass(wrapperClass);
            }
        } catch (InstantiationException e) {
            IntegrationException.failedToCreateWrapperInstance(wrapperClass.getName(), e);
        } catch (IllegalAccessException e) {
            IntegrationException.failedToCreateWrapperInstance(wrapperClass.getName(), e);
        }
        return wrapperInstance;
    }

    public static Wrapper wrap(Object entity) {
        Wrapper wrapperInstance = createEntityWrapper(defineWrapperClass(entity.getClass(), entity.getClass().getClassLoader()));
        wrapperInstance.wrap(entity);
        return wrapperInstance;
    }

    public static void removeFromCoherence(ClassDescriptor descriptor, AbstractSession interceptedSession, NamedCache namedCache, Object key, Object object, boolean shouldTranslatePKs) {
        Object cohKey = getCoherenceKey(descriptor, key, interceptedSession, shouldTranslatePKs);

        if (descriptor.getOptimisticLockingPolicy() != null && descriptor.getDefaultDeleteObjectQueryRedirector() != null) {
            if (interceptedSession.shouldLog(FINE, CACHE)) {
                interceptedSession.log(FINE, CACHE, "Coherence(" + namedCache.getCacheName() + ")::ConditionalRemove: " + cohKey, (Object[]) null, null, false);
            }
            Object result = namedCache.invoke(cohKey, CoherenceCacheHelper.createConditionalRemoveForOptLocking(descriptor, (VersionLockingPolicy) descriptor.getOptimisticLockingPolicy(), object));
            if (result != null) {
                DeleteObjectQuery query = new DeleteObjectQuery();
                query.setSession(interceptedSession);
                throw OptimisticLockException.objectChangedSinceLastReadWhenUpdating(object, query);
            }
        } else {
            if (interceptedSession.shouldLog(FINE, CACHE)) {
                interceptedSession.log(FINE, CACHE, "Coherence(" + namedCache.getCacheName() + ")::Remove: " + cohKey, (Object[]) null, null, false);
            }
            namedCache.remove(cohKey);
        }
    }

    /**
     * Translates From Grid id's to internal EclipseLink ids
     */
    public static Object[] translateToEclipseLinkPKs(Object[] cohKeys, ForeignReferenceMapping mapping, CMPPolicy cmpPolicy, AbstractSession session) {
        if (mapping != null && mapping.isCollectionMapping() && mapping.getContainerPolicy().isMapPolicy()){
            if (mapping.getContainerPolicy().isMappedKeyMapPolicy() && ((DatabaseMapping)((MappedKeyMapContainerPolicy)mapping.getContainerPolicy()).getKeyMapping()).isForeignReferenceMapping()){
                ClassDescriptor keyDescriptor = ((ForeignReferenceMapping)((MappedKeyMapContainerPolicy)mapping.getContainerPolicy()).getKeyMapping()).getReferenceDescriptor();
                if (keyDescriptor.hasCMPPolicy() && keyDescriptor.getCacheKeyType() == CacheKeyType.CACHE_ID){
                    for (int index = 0; index < cohKeys.length; index += 2){
                        cohKeys[index] = keyDescriptor.getCMPPolicy().createPrimaryKeyFromId(cohKeys[index], session);
                        cohKeys[index + 1] = cmpPolicy.createPrimaryKeyFromId(cohKeys[index + 1], session);
                    }
                    return cohKeys;
                }
            }
            //every other element is the PK
            for (int index = 1; index < cohKeys.length; index += 2) {
                cohKeys[index-1] = cohKeys[index-1];
                cohKeys[index] = cmpPolicy.createPrimaryKeyFromId(cohKeys[index], session);
            }
        } else {
            for (int index = 0; index < cohKeys.length; ++index) {
                cohKeys[index] = cmpPolicy.createPrimaryKeyFromId(cohKeys[index], session);
            }
        }
        return cohKeys;
    }

    /**
     * Translates From Grid id's to internal EclipseLink ids
     */
    public static Object[] translateToCoherencePKs(Object[] eclipseLinkKeys, ForeignReferenceMapping mapping, CMPPolicy cmpPolicy, AbstractSession session) {
        Object[] result = new Object[eclipseLinkKeys.length];
        if (mapping != null && mapping.isCollectionMapping() && mapping.getContainerPolicy().isMapPolicy()){
            if (mapping.getContainerPolicy().isMappedKeyMapPolicy() && ((DatabaseMapping)((MappedKeyMapContainerPolicy)mapping.getContainerPolicy()).getKeyMapping()).isForeignReferenceMapping()){
                ClassDescriptor keyDescriptor = ((ForeignReferenceMapping)((MappedKeyMapContainerPolicy)mapping.getContainerPolicy()).getKeyMapping()).getReferenceDescriptor();
                if (keyDescriptor.hasCMPPolicy() && keyDescriptor.getCacheKeyType() == CacheKeyType.CACHE_ID){
                    for (int index = 0; index < eclipseLinkKeys.length; index += 2){
                        result[index] = keyDescriptor.getCMPPolicy().createPrimaryKeyInstanceFromId(eclipseLinkKeys[index], session);
                        result[index + 1] = cmpPolicy.createPrimaryKeyInstanceFromId(eclipseLinkKeys[index + 1], session);
                    }
                    return result;
                }
            }
            //every other element is the PK
            for (int index = 1; index < eclipseLinkKeys.length; index += 2) {
                result[index-1] = eclipseLinkKeys[index-1];
                result[index] = cmpPolicy.createPrimaryKeyInstanceFromId(eclipseLinkKeys[index], session);
            }
        } else {
            for (int index = 0; index < eclipseLinkKeys.length; ++index) {
                result[index] = cmpPolicy.createPrimaryKeyInstanceFromId(eclipseLinkKeys[index], session);
            }
        }
        return result;
    }

    /**
     * Convert the internal EclipseLink primary key Vector into a single
     * identity object being either a basic value or an Id class.
     * 
     * @param descriptor
     * @param key
     * @return the key to be used for storage in Coherence
     */
    public static Object getCoherenceKey(ClassDescriptor descriptor, Object key, AbstractSession interceptedSession, boolean shouldTranslatePKs) {
        if (key == null || (descriptor.getCacheKeyType() == CacheKeyType.CACHE_ID && ((CacheId) key).getPrimaryKey() == null)) {
            throw new IllegalStateException("Cannot have null or empty PK vector");
        }
        if (shouldTranslatePKs && descriptor.hasCMPPolicy() && descriptor.getCMPPolicy().isCMP3Policy()) {
            try {
                CMP3Policy policy = (CMP3Policy) descriptor.getCMPPolicy();
                if (policy != null) {
                    return policy.createPrimaryKeyInstanceFromId(key, interceptedSession);
                }
            } catch (ClassCastException cce) {
            }
        }
        return key;
    }
    
    protected static List<DatabaseField> getKeyFields(DatabaseMapping mapping) {
        List<DatabaseField> keyFields = null;
        if (mapping.isObjectReferenceMapping()) {
            keyFields = ((ObjectReferenceMapping)mapping).getForeignKeyFields();
        } else if (mapping.isOneToManyMapping()) {
            keyFields = ((OneToManyMapping)mapping).getSourceKeyFields();
        } else if (mapping.isManyToManyMapping()) {
            keyFields = ((ManyToManyMapping)mapping).getSourceKeyFields();
        } else if (mapping.isDirectCollectionMapping() || mapping.isDirectMapMapping()) {
            keyFields = ((DirectCollectionMapping)mapping).getSourceKeyFields();
        } else if (mapping.isAggregateCollectionMapping()) {
            keyFields = ((AggregateCollectionMapping)mapping).getSourceKeyFields();
        } else if (mapping.isTransformationMapping()) {
            keyFields = ((TransformationMapping)mapping).getFields();
        } else {
            keyFields = new Vector<DatabaseField>();
        }
        
        return keyFields;
    }
 
    public static Object[] decomposeDatabaseRecord(AbstractRecord record, Collection<DatabaseField> keyFields) {
        Object[] row = new Object[2];
        String[] fields = new String[keyFields.size()];
        Vector<Object> values = new Vector<Object>();
        int index = 0;
        for (DatabaseField keyField : keyFields) {
            fields[index] = keyField.getQualifiedName();
            values.add(record.get(keyField));
            index++;
        }
        row[0] = fields;
        row[1] = values;
        return row;
    }

    protected static DatabaseRecord composeDatabaseRecord(Object[] record){
        Vector<DatabaseField> fields = new Vector<DatabaseField>();
        Object[] fieldNames = (Object[])record[0];
        for (int index = 0; index < fieldNames.length; ++index){
            fields.add(new DatabaseField((String) fieldNames[index]));
        }
        return new DatabaseRecord(fields, new Vector<Object>((List)record[1]));
    }
}
