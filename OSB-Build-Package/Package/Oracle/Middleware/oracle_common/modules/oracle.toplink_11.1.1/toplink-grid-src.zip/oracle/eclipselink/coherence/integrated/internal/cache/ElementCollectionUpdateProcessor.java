// Copyright (c) 1998, 2011, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.cache;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

import org.eclipse.persistence.mappings.AttributeAccessor;

import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofWriter;
import com.tangosol.io.pof.PortableObject;
import com.tangosol.util.Binary;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.InvocableMap.Entry;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.processor.AbstractProcessor;

public class ElementCollectionUpdateProcessor extends AbstractProcessor implements PortableObject{
 
 protected Object attributeValue;
 protected AttributeAccessor attributeAccessor;
 protected Object versionValue;
 protected AbstractExtractor extractor;

 public ElementCollectionUpdateProcessor(){
     super();
 }

 public ElementCollectionUpdateProcessor(Object attributeValue, AttributeAccessor attributeAccessor, Object versionValue, AbstractExtractor extractor){
     this.attributeValue = attributeValue;
     this.attributeAccessor = attributeAccessor;
     this.versionValue = versionValue;
     this.extractor = extractor;     
 }

 public Object process(Entry entry) {
     if (entry.isPresent()){
         if (extractor != null){
             Binary internalValue = ((BinaryEntry)entry).getBinaryValue();
             
             Comparable targetValue = (Comparable) ((BinaryEntry)entry).getContext().getInternalValueDecoration(internalValue, 4);
             if (targetValue == null){
                 targetValue = (Comparable) extractor.extract(entry.getValue());
             }
             if (targetValue != null && (targetValue.compareTo(versionValue) != 0)){
                 return null;
             }
         }
         WrapperInternal wrapper = (WrapperInternal)entry.getValue();
         Object object = wrapper.unwrap();
         if (!attributeAccessor.isInitialized()) {
             attributeAccessor.initializeAttributes(object.getClass());
         }
         attributeAccessor.setAttributeValueInObject(object, attributeValue);
         wrapper.getForeignKeys().remove(attributeAccessor.getAttributeName());
         wrapper.setShouldMerge(false);
         entry.setValue(wrapper, true);
     }
     return null;
 }

 @Override
 public Map processAll(Set setEntries) {
     return null;
 }

 public void readExternal(PofReader in) throws IOException {
     this.attributeValue = in.readObject(0);
     this.attributeAccessor = (AttributeAccessor)in.readObject(1);
     this.versionValue = in.readObject(2);
     this.extractor = (AbstractExtractor) in.readObject(3);
 }

 public void writeExternal(PofWriter out) throws IOException {
     out.writeObject(0, this.attributeValue);
     out.writeObject(1, this.attributeAccessor);
     out.writeObject(2, this.versionValue);
     out.writeObject(3, this.extractor);     
 }

}
