// Copyright (c) 1998, 2009, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.cache;

import java.io.Serializable;

import oracle.eclipselink.coherence.integrated.cache.Wrapper;
import oracle.eclipselink.coherence.integrated.internal.querying.EclipseLinkExtractor;

import org.eclipse.persistence.mappings.AttributeAccessor;

import com.tangosol.util.ValueExtractor;

/**
 * Used during conditional puts of Optimistically Locked objects. This Class is
 * used to extract the version value from the object.
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class LockVersionExtractor implements ValueExtractor, Serializable, EclipseLinkExtractor {

    protected AttributeAccessor accessor;
    protected String className;

    public LockVersionExtractor(AttributeAccessor accessor, String className) {
        this.accessor = accessor;
        this.className = className;
    }

    public Object extract(Object arg0) {
        if (arg0 == null)
            return null; // initial insert
        if (arg0 instanceof Wrapper){
            arg0 = ((Wrapper)arg0).unwrap();
        }
        if (!this.accessor.isInitialized()) {
            this.accessor.initializeAttributes(arg0.getClass());
        }
        return this.accessor.getAttributeValueFromObject(arg0);
    }

    public boolean equals(Object obj) {
        if (obj instanceof LockVersionExtractor) {
            return (((LockVersionExtractor) obj).accessor.getAttributeName().equals(this.accessor.getAttributeName()) && this.className.equals(((LockVersionExtractor) obj).className));
        }
        return super.equals(obj);
    }

    public String toString() {
        return "LockVersionExtractor : " + className;
    }

    /**
     * @return the accessor
     */
    public AttributeAccessor getAccessor() {
        return accessor;
    }

    /**
     * @return the className
     */
    public String getClassName() {
        return className;
    }

    /**
     * @param accessor the accessor to set
     */
    public void setAccessor(AttributeAccessor accessor) {
        this.accessor = accessor;
    }

    /**
     * @param className the className to set
     */
    public void setClassName(String className) {
        this.className = className;
    }


}
