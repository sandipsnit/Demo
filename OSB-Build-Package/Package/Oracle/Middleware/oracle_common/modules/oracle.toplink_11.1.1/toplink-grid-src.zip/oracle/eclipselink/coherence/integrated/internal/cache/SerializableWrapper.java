// Copyright (c) 1998, 2011, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.cache;

import java.util.Map;

/**
 * <p>
 * <b>Purpose:</b> This class is used as a generic wrapper class for non POF
 * serialization. It provides for serialization to a node which may not have the
 * correct dynamic wrapper defined which would otherwise result in an exception.
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class SerializableWrapper implements WrapperInternal {
    
    protected Object delegate;
    protected Map<String, Object[]> relationships;
    protected Map<String, Object[]> rows;
    protected String wrapperClassName;
    protected boolean shouldMerge = true;


    public Map getForeignKeys() {
        return rows;
    }

    public Map getPrimaryKeys() {
        return relationships;
    }

    public void setForeignKeys(Map foreignKeys) {
        this.rows = foreignKeys;

    }

    public void setPrimaryKeys(Map primaryKeys) {
        this.relationships = primaryKeys;

    }

    public void wrap(Object entity) {
        this.delegate = entity;

    }

    public Object[] getForeignKeyValuesFor(String propertyName) {
        return this.rows.get(propertyName);
    }

    public Object[] getPrimaryKeyValuesFor(String propertyName) {
        return this.relationships.get(propertyName);
    }

    public void setForeignKeyValuesFor(String propertyName, Object[] fks) {
        this.rows.put(propertyName, fks);
    }

    public void setPrimaryKeyValuesFor(String propertyName, Object[] pks) {
        this.relationships.put(propertyName, pks);
    }

    public Object unwrap() {
        return this.delegate;
    }

    public String getWrapperClassName() {
        return this.wrapperClassName;
    }

    public void setWrapperClassName(String wrapperClassName) {
        this.wrapperClassName = wrapperClassName;
    }
    
    public boolean shouldMerge() {
        return this.shouldMerge;
    }

    public void setShouldMerge(boolean shouldMerge) {
        this.shouldMerge = shouldMerge;
    }
}
