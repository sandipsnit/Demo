// Copyright (c) 1998, 2011, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.cache;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Map;
import java.util.Set;

import com.tangosol.util.Base;
import com.tangosol.util.Binary;
import com.tangosol.util.BinaryEntry;
import com.tangosol.util.ExternalizableHelper;
import com.tangosol.io.ExternalizableLite;
import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofWriter;
import com.tangosol.io.pof.PortableObject;
import com.tangosol.util.Filter;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.InvocableMap.Entry;
import com.tangosol.util.InvocableMap.EntryProcessor;
import com.tangosol.util.extractor.AbstractExtractor;
import com.tangosol.util.processor.AbstractProcessor;

/**
 * This is an implementation of an OptimisticLock based entry updater. This
 * allows us to report a failed put.
 * 
 * @author gyorke
 * @since Oracle TopLink 11g (11.1.1.4.0)
 */
public class VersionPutProcessor extends AbstractProcessor implements ExternalizableLite, PortableObject {

    protected Object versionValue;
    protected Object objectToPut;
    protected boolean returnFailure;
    protected AbstractExtractor valueExtractor;

    public VersionPutProcessor() {
        super();
    }

    public VersionPutProcessor(Object versionValue, AbstractExtractor valueExtractor, Object objectToPut, boolean returnFailure) {
        this.versionValue = versionValue;
        this.objectToPut = objectToPut;
        this.returnFailure = returnFailure;
        this.valueExtractor = valueExtractor;
    }

    @Override
    public Object process(Entry entry) {
        Binary internal = null;
            internal = (Binary) objectToPut;
        if (!entry.isPresent()){
            ((BinaryEntry)entry).updateBinaryValue((Binary) ((BinaryEntry)entry).getContext().addInternalValueDecoration(internal, 4, this.versionValue));
        }else{
            Binary internalValue = ((BinaryEntry)entry).getBinaryValue();
            
            Object version = ((BinaryEntry)entry).getContext().getInternalValueDecoration(internalValue, 4);
            if (version == null){
                version = valueExtractor.extract(entry.getValue());
            }
            if (((Comparable)version).compareTo(versionValue) <= 0 ){ // changes to collections do not update version values
               ((BinaryEntry)entry).updateBinaryValue((Binary) ((BinaryEntry)entry).getContext().addInternalValueDecoration(internal, 4, this.versionValue));
            }else{
                if (returnFailure){
                     return Boolean.FALSE;
                }
            }
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    public void readExternal(DataInput in) throws IOException {
        this.versionValue = ExternalizableHelper.readObject(in);
        this.valueExtractor = (AbstractExtractor) ExternalizableHelper.readObject(in);
        this.objectToPut = ExternalizableHelper.readObject(in);
        this.returnFailure = in.readBoolean();
    }

    /**
     * {@inheritDoc}
     */
    public void writeExternal(DataOutput out) throws IOException {
        ExternalizableHelper.writeObject(out, versionValue);
        ExternalizableHelper.writeObject(out, this.valueExtractor);
        ExternalizableHelper.writeObject(out, objectToPut);
        out.writeBoolean(returnFailure);
    }

    @Override
    public void readExternal(PofReader in) throws IOException {
        this.versionValue = in.readObject(1);
        this.valueExtractor = (AbstractExtractor) in.readObject(2);
        this.objectToPut = in.readBinary(3);
        this.returnFailure = in.readBoolean(4);
    }

    @Override
    public void writeExternal(PofWriter out) throws IOException {
        out.writeObject(1, this.versionValue);
        out.writeObject(2, this.valueExtractor);
        out.writeBinary(3, (Binary) objectToPut);
        out.writeBoolean(4, returnFailure);
    }

}
