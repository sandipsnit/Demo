// Copyright (c) 1998, 2011, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.cache;

import java.util.Map;

import oracle.eclipselink.coherence.integrated.cache.Wrapper;

/**
 * <p>
 * <b>Purpose:</b> This interface will be user to access internal attributes of the Entity wrappers.
 *
 *@author gyorke
 *@since
 */
public interface WrapperInternal extends Wrapper {
    public void setForeignKeys(Map<String, Object[]> foreignKeys);
    public Map<String, Object[]> getForeignKeys();
    public void setPrimaryKeys(Map<String, Object[]> primaryKeys);
    public Map<String, Object[]> getPrimaryKeys();
    public void wrap(Object entity);
    public String getWrapperClassName();
    public void setWrapperClassName(String wrapperClassName);
    /**
     * This method indicates whether Wrapper stored into cache should be merged into the database.
     */
    public boolean shouldMerge();
    public void setShouldMerge(boolean shouldMerge);
}
