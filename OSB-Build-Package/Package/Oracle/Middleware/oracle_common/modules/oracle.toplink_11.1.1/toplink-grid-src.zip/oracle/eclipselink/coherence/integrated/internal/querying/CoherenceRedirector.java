// Copyright (c) 1998, 2011, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.querying;

import oracle.eclipselink.coherence.IntegrationProperties;
import oracle.eclipselink.coherence.exceptions.IntegrationException;
import oracle.eclipselink.coherence.integrated.internal.cache.CoherenceCacheHelper;
import oracle.eclipselink.coherence.integrated.querying.FilterFactory;
import oracle.eclipselink.coherence.integrated.querying.TranslationFailureDelegate;

import org.eclipse.persistence.descriptors.ClassDescriptor;
import org.eclipse.persistence.sessions.Session;

import com.tangosol.net.NamedCache;

/**
 * <p>
 * <b>Purpose:</b> Helper abstract class for interacting with the Coherence
 * Caches. Subclasses will have cached access to the Coherence Cache of a
 * particular name. The name should be stored within a class descriptor's
 * properties using the property "coherence.cache.name"
 * 
 * @author Gordon Yorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */

public abstract class CoherenceRedirector {
    protected NamedCache namedCache;

    protected FilterFactory filterFactory;
    
    protected TranslationFailureDelegate translationDelegate;
    
    protected Boolean shouldTranslatePKs;
    
    public FilterFactory getFilterFactory(Session session){
        if (this.filterFactory == null){
            this.filterFactory = FilterFactoryResolver.resolve(session);
        }
        return this.filterFactory;
    }

    public TranslationFailureDelegate getTranslationFailureDelegate(Session session){
        if (this.translationDelegate == null){
            this.translationDelegate = TranslationFailureDelegateResolver.resolve(session);
        }
        return this.translationDelegate;
    }
    

    protected NamedCache getNamedCache(ClassDescriptor descriptor, Session session) {
        if (this.namedCache == null) {
            try {
                this.namedCache = CoherenceCacheHelper.getNamedCache(descriptor, session);
            } catch (Exception ex) {
                throw IntegrationException.unableToFindCoherenceCache(CoherenceCacheHelper.getCacheName(descriptor), ex);
            }
        }
        return this.namedCache;
    }
    
    protected boolean shouldTranslatePKs(Session session){
    	if (this.shouldTranslatePKs == null){
            Object property = session.getProperty(IntegrationProperties.USE_TOPLINK_ID_CLASSES);
            if (property != null && property instanceof String && ((String)property).toLowerCase().equals("false")){
            	this.shouldTranslatePKs = false;
            }else{
            	this.shouldTranslatePKs = true;
            }
    	}
    	return this.shouldTranslatePKs;
    }

}
