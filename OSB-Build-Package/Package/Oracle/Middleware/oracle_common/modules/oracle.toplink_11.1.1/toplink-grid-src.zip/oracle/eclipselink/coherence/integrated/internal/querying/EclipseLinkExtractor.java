// Copyright (c) 1998, 2009, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.querying;

import org.eclipse.persistence.mappings.AttributeAccessor;

/**
 * <p>
 * <b>Purpose:</b> This interface is used for Coherence POF serialization to mark an
 * EclipseLink Extractor for serialization.
 *
 *@author gyorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public interface EclipseLinkExtractor {
    /**
     * INTERNAL:
     * Returns a reference to the AttributeAccessor used by the extractor.
     */
    public AttributeAccessor getAccessor();
    
    /**
     * INTERNAL:
     */
    public void setAccessor(AttributeAccessor accessor);

}
