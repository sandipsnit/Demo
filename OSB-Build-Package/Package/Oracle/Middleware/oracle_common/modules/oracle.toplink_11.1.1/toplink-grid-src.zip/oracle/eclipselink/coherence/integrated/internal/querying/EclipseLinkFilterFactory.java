// Copyright (c) 1998, 2011, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.querying;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.WeakHashMap;

import oracle.eclipselink.coherence.exceptions.IntegrationException;
import oracle.eclipselink.coherence.integrated.cache.Wrapper;
import oracle.eclipselink.coherence.integrated.querying.FilterFactory;

import org.eclipse.persistence.descriptors.ClassDescriptor;
import org.eclipse.persistence.expressions.Expression;
import org.eclipse.persistence.expressions.ExpressionBuilder;
import org.eclipse.persistence.expressions.ExpressionOperator;
import org.eclipse.persistence.internal.descriptors.ObjectBuilder;
import org.eclipse.persistence.internal.expressions.ConstantExpression;
import org.eclipse.persistence.internal.expressions.FieldExpression;
import org.eclipse.persistence.internal.expressions.FunctionExpression;
import org.eclipse.persistence.internal.expressions.LogicalExpression;
import org.eclipse.persistence.internal.expressions.ParameterExpression;
import org.eclipse.persistence.internal.expressions.QueryKeyExpression;
import org.eclipse.persistence.internal.expressions.RelationExpression;
import org.eclipse.persistence.internal.helper.BasicTypeHelperImpl;
import org.eclipse.persistence.internal.helper.ClassConstants;
import org.eclipse.persistence.internal.helper.DatabaseField;
import org.eclipse.persistence.internal.queries.ReportItem;
import org.eclipse.persistence.internal.sessions.AbstractSession;
import org.eclipse.persistence.logging.SessionLog;
import org.eclipse.persistence.mappings.DatabaseMapping;
import org.eclipse.persistence.queries.ObjectLevelReadQuery;
import org.eclipse.persistence.queries.ReadAllQuery;
import org.eclipse.persistence.queries.ReportQuery;
import org.eclipse.persistence.sessions.Record;
import org.eclipse.persistence.sessions.Session;

import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofWriter;
import com.tangosol.io.pof.PortableObject;
import com.tangosol.util.ExternalizableLite;
import com.tangosol.util.Filter;
import com.tangosol.util.InvocableMap;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.InvocableMap.EntryProcessor;
import com.tangosol.util.aggregator.BigDecimalAverage;
import com.tangosol.util.aggregator.BigDecimalMax;
import com.tangosol.util.aggregator.BigDecimalMin;
import com.tangosol.util.aggregator.BigDecimalSum;
import com.tangosol.util.aggregator.ComparableMax;
import com.tangosol.util.aggregator.ComparableMin;
import com.tangosol.util.aggregator.Count;
import com.tangosol.util.aggregator.DoubleAverage;
import com.tangosol.util.aggregator.DoubleMax;
import com.tangosol.util.aggregator.DoubleMin;
import com.tangosol.util.aggregator.DoubleSum;
import com.tangosol.util.aggregator.LongMax;
import com.tangosol.util.aggregator.LongMin;
import com.tangosol.util.aggregator.LongSum;
import com.tangosol.util.extractor.IdentityExtractor;
import com.tangosol.util.filter.AllFilter;
import com.tangosol.util.filter.AlwaysFilter;
import com.tangosol.util.filter.AnyFilter;
import com.tangosol.util.filter.BetweenFilter;
import com.tangosol.util.filter.EqualsFilter;
import com.tangosol.util.filter.GreaterEqualsFilter;
import com.tangosol.util.filter.GreaterFilter;
import com.tangosol.util.filter.InFilter;
import com.tangosol.util.filter.LessEqualsFilter;
import com.tangosol.util.filter.LessFilter;
import com.tangosol.util.filter.LikeFilter;
import com.tangosol.util.filter.NotFilter;
import com.tangosol.util.processor.ExtractorProcessor;

/**
 * <p>
 * <b>Purpose:</b> This class is used to translate from the EclipseLink queries
 * to the Coherence filters. This class attempts to maintain a cache of
 * translated expressions to make the translation process faster. Using named
 * queries will ensure the cache is leveraged. Setting the property
 * (coherence.do-not-translate-queries) on your query will instruct the
 * FilterFactory to not process the query and instead cause EclipseLink to
 * execute the query.
 * 
 * @author Gordon Yorke
 * @author Shaun Smith
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */

public class EclipseLinkFilterFactory implements FilterFactory{

    protected static Map<Expression, Filter> expressionCache = new WeakHashMap<Expression, Filter>();

    public Filter create(ObjectLevelReadQuery query, Record args, Session session) {
        if (!query.getJoinedAttributeExpressions().isEmpty() || query.getLockMode() > 0 || query.getAsOfClause() != null)
            return NO_FILTER;
        if (query.isReadAllQuery()) {
            ReadAllQuery localQuery = (ReadAllQuery) query;
            if (!localQuery.getOrderByExpressions().isEmpty()) {
                return NO_FILTER;
            }
        }
        Expression expression = query.getSelectionCriteria();
        Filter cachedFilter = null;
        if (query.isCustomQueryUsed() != null && query.isCustomQueryUsed().booleanValue()) {
            cachedFilter = expressionCache.get(expression);
        }
        // include null as well
        if (cachedFilter != null) {
            if (cachedFilter == NO_FILTER) {
                return null;
            } else {
                return cachedFilter;
            }
        }
        query.getExpressionBuilder().setSession((AbstractSession) session);
        query.getExpressionBuilder().setQueryClass(query.getReferenceClass());
        cachedFilter = this.create(expression, args, (AbstractSession) session);
        //only store descriptor queries and names queries as the list would be considered a memory leak.
        if (cachedFilter == null) {
            cachedFilter = NO_FILTER;
            if ((query.isCustomQueryUsed() != null && query.isCustomQueryUsed().booleanValue()) || query.getName() != null)
                expressionCache.put(expression, NO_FILTER);
        } else {
            if (query.getDescriptor().hasInheritance()){
                List<Filter> filters = new ArrayList<Filter>();
                flattenAllFilters(filters, cachedFilter);
                flattenAllFilters(filters, new SubClassOf(query.getReferenceClass()));
                cachedFilter = new AllFilter(filters.toArray(new Filter[filters.size()]));
            }
            if ((query.isCustomQueryUsed() != null && query.isCustomQueryUsed().booleanValue()) || query.getName() != null)
                expressionCache.put(expression, cachedFilter);
        }
        return cachedFilter;
    }

    protected Filter create(Expression expression, Record args, AbstractSession session) {
        if (expression == null) {
            // no expression means all objects of this class should be returned
            return new AlwaysFilter();
        }
        if (expression.isLogicalExpression()) {
            return createLogical((LogicalExpression) expression, args, session);
        }
        if (expression.isRelationExpression()) {
            RelationExpression relExp = (RelationExpression) expression;

            switch (relExp.getOperator().getSelector()) {
            case ExpressionOperator.Equal:
                return createEquals(relExp, args, session);
            case ExpressionOperator.NotEqual:
                return createNotEquals(relExp, args, session);
            case ExpressionOperator.GreaterThan:
                return createGreaterThan(relExp, args, session);
            case ExpressionOperator.GreaterThanEqual:
                return createGreaterThanEquals(relExp, args, session);
            case ExpressionOperator.LessThan:
                return createLessThan(relExp, args, session);
            case ExpressionOperator.LessThanEqual:
                return createLessThanEquals(relExp, args, session);
            case ExpressionOperator.In:
                return createIn(relExp, args, session);
            }
        }

        if (expression.isFunctionExpression()) {
            FunctionExpression funcExp = (FunctionExpression) expression;

            switch (funcExp.getOperator().getSelector()) {
            case ExpressionOperator.IsNull:
                return createIsNull(funcExp, session);
            case ExpressionOperator.NotNull:
                return createNotNull(funcExp, session);
            case ExpressionOperator.Between:
                return createBetween(funcExp, session);
            case ExpressionOperator.Like:
                return createLike(funcExp, args, session);
            }
        }
        session.log(SessionLog.WARNING, SessionLog.QUERY, "expression_not_supported_by_filter_factory");
        return null; // null means we could not translate this expression
    }

    protected Filter createLogical(LogicalExpression expression, Record args, AbstractSession session) {
        switch (expression.getOperator().getSelector()) {
        case ExpressionOperator.And:
            return createAnd(expression, args, session);
        case ExpressionOperator.Or:
            return createOr(expression, args, session);
        }
        throw new IllegalArgumentException("ExpressionFilterConverter.createLogical::failed with unknown logical expression: " + expression);
    }

    protected AllFilter createAnd(LogicalExpression expression, Record args, AbstractSession session) {
        Filter leftFilter = create(expression.getFirstChild(), args, session);
        Filter rightFilter = create(expression.getSecondChild(), args, session);
        if (leftFilter != null && rightFilter != null) {
            List<Filter> filters = new ArrayList<Filter>();
            flattenAllFilters(filters, leftFilter);
            flattenAllFilters(filters, rightFilter);
            return new AllFilter(filters.toArray(new Filter[filters.size()]));
        } else {
            return null;
        }
    }

    private void flattenAllFilters(List<Filter> filters, Filter filter) {
        if (filter instanceof AllFilter) { // AndFilter extends AllFilter
            AllFilter allFilter = (AllFilter) filter;
            Filter[] allFilters = allFilter.getFilters();
            for (int i = 0; i < allFilters.length; i++) {
                Filter eachFilter = allFilters[i];
                filters.add(eachFilter);
            }
        } else {
            filters.add(filter);
        }
    }

    protected AnyFilter createOr(LogicalExpression expression, Record args, AbstractSession session) {
        Filter leftFilter = create(expression.getFirstChild(), args, session);
        Filter rightFilter = create(expression.getSecondChild(), args, session);
        if (leftFilter != null && rightFilter != null) {
            List<Filter> filters = new ArrayList<Filter>();
            flattenOrFilters(filters, leftFilter);
            flattenOrFilters(filters, rightFilter);
            return new AnyFilter(filters.toArray(new Filter[filters.size()]));
        } else {
            return null;
        }
    }

    private void flattenOrFilters(List<Filter> filters, Filter filter) {
        if (filter instanceof AnyFilter) { // OrFilter extends AnyFilter
            AnyFilter allFilter = (AnyFilter) filter;
            Filter[] allFilters = allFilter.getFilters();
            for (int i = 0; i < allFilters.length; i++) {
                Filter eachFilter = allFilters[i];
                filters.add(eachFilter);
            }
        } else {
            filters.add(filter);
        }
    }

    protected IsNull createIsNull(FunctionExpression expression, AbstractSession session) {
        if (expression.getBaseExpression().isQueryKeyExpression()) {
            QueryKeyExpression qkExp = (QueryKeyExpression) expression.getBaseExpression();
            ValueExtractor extractor = createValueExtractor(qkExp, session);
            if (extractor != null) {
                return new IsNull(extractor);
            }
        }
        return null;
    }

    protected IsNotNull createNotNull(FunctionExpression expression, AbstractSession session) {
        if (expression.getBaseExpression().isQueryKeyExpression()) {
            QueryKeyExpression qkExp = (QueryKeyExpression) expression.getBaseExpression();
            ValueExtractor extractor = createValueExtractor(qkExp, session);
            if (extractor != null) {
                return new IsNotNull(extractor);
            }
        }
        return null;
    }

    protected BetweenFilter createBetween(FunctionExpression expression, AbstractSession session) {
        if (expression.getBaseExpression().isQueryKeyExpression()) {
            QueryKeyExpression qkExp = (QueryKeyExpression) expression.getBaseExpression();
            FilterExtractor extractor = createValueExtractor(qkExp, session);
            if (extractor != null) {
                Comparable lowerValue;
                Comparable upperValue;
                try {
                    ConstantExpression lower = (ConstantExpression) expression.getChildren().get(1);
                    ConstantExpression upper = (ConstantExpression) expression.getChildren().get(2);
                    lowerValue = (Comparable) lower.getValue();
                    lowerValue = (Comparable) session.getPlatform().convertObject(lowerValue, extractor.getAttributeClass());
                    upperValue = (Comparable) upper.getValue();
                    upperValue = (Comparable) session.getPlatform().convertObject(upperValue, extractor.getAttributeClass());
                } catch (ClassCastException e) {
                    session.log(SessionLog.WARNING, SessionLog.QUERY, "Failed to convert query: " + expression.toString() + " to Coherence filter: between() expression only supports constant numberic values.", (Object[]) null, null, false);
                    return null;
                }
                return new BetweenFilter(extractor, lowerValue, upperValue);
            }
        }
        return null;
    }

    protected EqualsFilter createEquals(RelationExpression expression, Record args, AbstractSession session) {
        FilterExtractor extractor = createValueExtractor(expression.getFirstChild(), session);
        if (extractor != null) {
            Object value = getValue(expression.getSecondChild(), args, session, extractor.getAttributeClass());
            if (value != null)
                return new EqualsFilter(extractor, value);
        }
        return null;
    }

    protected NotFilter createNotEquals(RelationExpression expression, Record args, AbstractSession session) {
        if (expression.getFirstChild().isQueryKeyExpression()) {
            QueryKeyExpression qkExp = (QueryKeyExpression) expression.getFirstChild();
            FilterExtractor extractor = createValueExtractor(qkExp, session);
            if (extractor != null) {
                Object value = getValue(expression.getSecondChild(), args, session, extractor.getAttributeClass());
                if (value != null)
                    return new NotFilter(new EqualsFilter(extractor, value));
            }
        }
        return null;
    }

    protected LessFilter createLessThan(RelationExpression expression, Record args, AbstractSession session) {
        if (expression.getFirstChild().isQueryKeyExpression()) {
            QueryKeyExpression qkExp = (QueryKeyExpression) expression.getFirstChild();
            FilterExtractor extractor = createValueExtractor(qkExp, session);
            if (extractor != null) {
                Object value = getValue(expression.getSecondChild(), args, session, extractor.getAttributeClass());
                if (value != null)
                    return new LessFilter(extractor, (Comparable) value);
            }
        }
        return null;
    }

    protected LessEqualsFilter createLessThanEquals(RelationExpression expression, Record args, AbstractSession session) {
        if (expression.getFirstChild().isQueryKeyExpression()) {
            QueryKeyExpression qkExp = (QueryKeyExpression) expression.getFirstChild();
            FilterExtractor extractor = createValueExtractor(qkExp, session);
            if (extractor != null) {
                Object value = getValue(expression.getSecondChild(), args, session, extractor.getAttributeClass());
                if (value != null) {
                    return new LessEqualsFilter(extractor, (Comparable) value);
                }
            }
        }
        return null;
    }

    protected GreaterFilter createGreaterThan(RelationExpression expression, Record args, AbstractSession session) {
        if (expression.getFirstChild().isQueryKeyExpression()){
            QueryKeyExpression qkExp = (QueryKeyExpression) expression.getFirstChild();
            FilterExtractor extractor = createValueExtractor(qkExp, session);
            if (extractor != null) {
                Object value = getValue(expression.getSecondChild(), args, session, extractor.getAttributeClass());
                if (value != null)
                    return new GreaterFilter(extractor, (Comparable) value);
            }
        }
        return null;
    }

    protected GreaterEqualsFilter createGreaterThanEquals(RelationExpression expression, Record args, AbstractSession session) {
        if (expression.getFirstChild().isQueryKeyExpression()) {
            QueryKeyExpression qkExp = (QueryKeyExpression) expression.getFirstChild();
            FilterExtractor extractor = createValueExtractor(qkExp, session);
            if (extractor != null) {
                Object value = getValue(expression.getSecondChild(), args, session, extractor.getAttributeClass());
                if (value != null)
                    return new GreaterEqualsFilter(extractor, (Comparable) value);
            }
        }
        return null;
    }

    protected LikeFilter createLike(FunctionExpression expression, Record args, AbstractSession session) {
        if (expression.getChildren().size() > 2) {
            return null;
        }
        if (((Expression) expression.getChildren().get(0)).isQueryKeyExpression()) {
            QueryKeyExpression qkExp = (QueryKeyExpression) expression.getChildren().get(0);
            FilterExtractor extractor = createValueExtractor(qkExp, session);
            String pattern = (String) getValue((Expression) expression.getChildren().get(1), args, session, ClassConstants.STRING);
            if (extractor != null) {
                return new LikeFilter(extractor, pattern, '\\', false);
            }
        }
        return null;
    }

    protected InFilter createIn(RelationExpression expression, Record args, AbstractSession session) {
    	if (expression.getFirstChild().isQueryKeyExpression()){
	        QueryKeyExpression qkExp = (QueryKeyExpression) expression.getFirstChild();
	        FilterExtractor extractor = createValueExtractor(qkExp, session);
	        if (extractor != null) {
	            Vector<Object> values = (Vector<Object>) getValue(expression.getSecondChild(), args, session, extractor.getAttributeClass());
	            if (values != null)
	                return new InFilter(extractor, new HashSet<Object>(values));
	        }
    	}
        return null;
    }

    protected Object getValue(Expression expression, Record args, AbstractSession session, Class targetClass) {
        if (expression.isConstantExpression()) {
            Object value = ((ConstantExpression) expression).getValue();
            if (value instanceof Collection) {
                Collection newValue;
                try {
                    newValue = (Collection) value.getClass().newInstance();
                } catch (InstantiationException e) {
                    session.log(SessionLog.WARNING, SessionLog.QUERY, "Instantiation exception when converting collection parameter: " + expression + " with args: " + args, (Object[]) null, null, false);
                    return null;
                } catch (IllegalAccessException e) {
                    session.log(SessionLog.WARNING, SessionLog.QUERY, "IllegalAccessException when converting collection parameter: " + expression + " with args: " + args, (Object[]) null, null, false);
                    return null;
                }
                for (Iterator iterator = ((Collection) value).iterator(); iterator.hasNext();) {
                    newValue.add(session.getPlatform().convertObject(iterator.next(), targetClass));
                }
                return newValue;
            }
            return session.getPlatform().convertObject(value, targetClass);
        }

        if (expression.isParameterExpression() && session.getDescriptor(targetClass) == null) { // this may be a target FK query for a relationship
            DatabaseField field = ((ParameterExpression) expression).getField();
            if (args.containsKey(field)) {
                Object value = args.get(field);
                if (value instanceof Collection) {
                    Collection newValue;
                    try {
                        newValue = (Collection) value.getClass().newInstance();
                    } catch (InstantiationException e) {
                        session.log(SessionLog.WARNING, SessionLog.QUERY, "Instantiation exception when converting collection parameter: " + expression + " with args: " + args, (Object[]) null, null, false);
                        return null;
                    } catch (IllegalAccessException e) {
                        session.log(SessionLog.WARNING, SessionLog.QUERY, "IllegalAccessException when converting collection parameter: " + expression + " with args: " + args, (Object[]) null, null, false);
                        return null;
                    }
                    for (Iterator iterator = ((Collection) value).iterator(); iterator.hasNext();) {
                        newValue.add(session.getPlatform().convertObject(iterator.next(), targetClass));
                    }
                    return newValue;
                }
                return session.getPlatform().convertObject(value, targetClass);
            }
        }
        session.log(SessionLog.WARNING, SessionLog.QUERY, "FilterFactory.getValue does not support: " + expression + " with args: " + args, (Object[]) null, null, false);
        return null;
    }

    /**
     * Create a value extractor that can be used on the grid. For now this will
     * assume field access on attributes directly on the reference class.
     * 
     * TODO: Support multi-level expressions TODO: Support wrappers (Coherence
     * externalization)
     */
    public FilterExtractor createValueExtractor(Expression expression, AbstractSession session) {
        if (expression.isQueryKeyExpression()) {
            QueryKeyExpression qkExp = (QueryKeyExpression) expression;
            if (qkExp.getBaseExpression() != null && !qkExp.getBaseExpression().isExpressionBuilder()) {
                session.log(SessionLog.WARNING, SessionLog.QUERY, "FilterFactory.createValueExtractor::Does not support: " + expression + ". Query across relationship not supported", (Object[]) null, null, false);
                return null;
            }
            DatabaseMapping mapping = qkExp.getContainingDescriptor().getMappingForAttributeName(expression.getName());
            if (mapping == null) {
                session.log(SessionLog.WARNING, SessionLog.QUERY, "FilterFactory.createValueExtractor::Does not support: " + expression + ". Unknown mapping attribute: " + expression.getName(), (Object[]) null, null, false);
                return null;
            }
            return new FilterExtractor(mapping);
        }

        if (expression.isFieldExpression()) {
            FieldExpression fieldExp = (FieldExpression) expression;
            //This is broken up onto multiple lines to get better information in case a null pointer occurs
            // The null pointer was reported by QA but has not be reproduced.
            ExpressionBuilder builder = fieldExp.getBuilder();
            ClassDescriptor desc = builder.getDescriptor();
            ObjectBuilder oBuilder = desc.getObjectBuilder();
            DatabaseMapping mapping = oBuilder.getMappingForField(fieldExp.getField());
            if (mapping == null) {
                session.log(SessionLog.WARNING, SessionLog.QUERY, "FilterFactory.createValueExtractor::Does not support: " + expression + ". Unknown mapping attribute: " + fieldExp.getField(), (Object[]) null, null, false);
                return null;
            }
            if (mapping.isForeignReferenceMapping()) {
                session.log(SessionLog.WARNING, SessionLog.QUERY, "FilterFactory.createValueExtractor::Does not support: " + expression + ". Query across relationship not supported", (Object[]) null, null, false);
                return null;
            }
            return new FilterExtractor(mapping);
        }

        session.log(SessionLog.WARNING, SessionLog.QUERY, "FilterFactory.createValueExtractor::Does not support: " + expression, (Object[]) null, null, false);
        return null;
    }

    /***
     * IsNotNull is equivalent to Coherence's IsNotNullFilter except that it
     * provides support for a ValueExtractor instead of an explicit method name.
     * 
     * @author Shaun Smith
     * 
     */
    public static class IsNotNull extends EqualsFilter {

        public IsNotNull() {
            // Required for
        }

        public IsNotNull(ValueExtractor extractor) {
            super(extractor, null);
        }

        @Override
        protected boolean evaluateExtracted(Object extracted) {
            return extracted != null;
        }

    }

    /***
     * IsNull is equivalent to Coherence's IsNullFilter except that it provides
     * support for a ValueExtractor instead of an explicit method name.
     * 
     * @author Shaun Smith
     * 
     */
    public static class IsNull extends EqualsFilter {

        public IsNull() {
            // Required for
        }

        public IsNull(ValueExtractor extractor) {
            super(extractor, null);
        }

        @Override
        protected boolean evaluateExtracted(Object extracted) {
            return extracted == null;
        }

    }
    
    /**
     * This filter is added to filter out superclasses that may be outside of the scope of a polymorphic query.
     * ie.  C inherits from B which inherits from A.  All will be stored in same cache but a query on B should not
     * return any As.
     * 
     * @author gyorke
     *
     */
    public static class SubClassOf implements Filter, Serializable, PortableObject, ExternalizableLite{

        protected transient Class parentClass;
        protected String parentClassName;
        
        public SubClassOf(){
        }

        public SubClassOf(Class parentClass){
            this.parentClass = parentClass;
            this.parentClassName = parentClass.getName();
        }

        public boolean evaluate(Object arg0) {
            if (arg0 instanceof Wrapper){
                arg0 = ((Wrapper)arg0).unwrap();
            }
            if (parentClass == null){
                try {
                    parentClass = arg0.getClass().getClassLoader().loadClass(parentClassName);
                } catch (ClassNotFoundException e) {
                    throw IntegrationException.noClassFoundSubClassFilter(parentClassName, arg0.getClass().getClassLoader(), e);
                }
            }
            return parentClass.isAssignableFrom(arg0.getClass());
        }
        
        @Override
        public void readExternal(PofReader in) throws IOException {
            parentClassName = in.readString(0);
            
        }
        @Override
        public void writeExternal(PofWriter out) throws IOException {
            out.writeString(0,this.parentClassName);
            
        }
        @Override
        public void readExternal(DataInput in) throws IOException {
            parentClassName = in.readLine();
            
        }
        @Override
        public void writeExternal(DataOutput out) throws IOException {
            out.writeBytes(parentClassName);
            out.writeBytes("\n");
        }
        
        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((parentClass == null) ? 0 : parentClass.hashCode());
            return result;
        }
        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            SubClassOf other = (SubClassOf) obj;
            if (parentClass == null) {
                if (other.parentClass != null)
                    return false;
            } else if (!parentClass.equals(other.parentClass))
                return false;
            return true;
        }
        

    }

    /**
     * Translates ReportQueryItem into an equivalent Coherence artifact
     */
    public InvocableMap.EntryAggregator createAggregator(ReportItem item, ReportQuery query, Record args, AbstractSession session) {
        FunctionExpression expression = (FunctionExpression) item.getAttributeExpression();
        boolean setSession = expression.getBuilder().getSession() == null;
        if (setSession){
            expression.getBuilder().setSession(session);
        }
        try {
            Class<?> resultType = ((FunctionExpression) expression).getResultType();
            FilterExtractor extractor = this.createValueExtractor(expression.getBaseExpression(), session);
            if (resultType == null) {
                resultType = extractor.getAttributeClass();
            }
            switch (expression.getOperator().getSelector()) {
            case ExpressionOperator.Count:
                return new Count();
            case ExpressionOperator.Sum:
                if (BasicTypeHelperImpl.getInstance().isIntegralType(resultType)) {
                    return new LongSum(extractor);
                }
                if (BasicTypeHelperImpl.getInstance().isFloatingPointType(resultType)) {
                    return new DoubleSum(extractor);
                }
                if (resultType.equals(ClassConstants.BIGDECIMAL)) {
                    return new BigDecimalSum(extractor);
                }
                break;
            case ExpressionOperator.Average:
                if (BasicTypeHelperImpl.getInstance().isFloatingPointType(resultType)) {
                    return new DoubleAverage(extractor);
                }
                if (resultType.equals(ClassConstants.BIGDECIMAL)) {
                    return new BigDecimalAverage(extractor);
                }
                break;
            case ExpressionOperator.Minimum:
                if (BasicTypeHelperImpl.getInstance().isIntegralType(resultType)) {
                    return new LongMin(extractor);
                }
                if (BasicTypeHelperImpl.getInstance().isFloatingPointType(resultType)) {
                    return new DoubleMin(extractor);
                }
                if (resultType.equals(ClassConstants.BIGDECIMAL)) {
                    return new BigDecimalMin(extractor);
                }
                if (resultType.isAssignableFrom(Comparable.class)) {
                    return new ComparableMin(extractor);
                }
                break;
            case ExpressionOperator.Maximum:
                if (BasicTypeHelperImpl.getInstance().isIntegralType(resultType)) {
                    return new LongMax(extractor);
                }
                if (BasicTypeHelperImpl.getInstance().isFloatingPointType(resultType)) {
                    return new DoubleMax(extractor);
                }
                if (resultType.equals(ClassConstants.BIGDECIMAL)) {
                    return new BigDecimalMax(extractor);
                }
                if (resultType.isAssignableFrom(Comparable.class)) {
                    return new ComparableMax(extractor);
                }
                break;
            default:
                break;
            }
            return null;
        } finally {
            if (setSession)
                expression.getBuilder().setSession(null);

        }
    }

    public EntryProcessor createValueExtractor(ReportItem item, ReportQuery query, Record args, AbstractSession session) {
        Expression expression = item.getAttributeExpression();
        boolean setSession = expression.getBuilder().getSession() == null;
        if (setSession)
            expression.getBuilder().setSession(session);
        try {
            if (expression.isQueryKeyExpression() || expression.isFieldExpression()) {
                return new ExtractorProcessor(this.createValueExtractor(expression, session));
            }
            if (expression.isExpressionBuilder()) {
                return new ExtractorProcessor(IdentityExtractor.INSTANCE);
            }

            return null;
        } finally {
            if (setSession)
                expression.getBuilder().setSession(null);

        }
    }

}
