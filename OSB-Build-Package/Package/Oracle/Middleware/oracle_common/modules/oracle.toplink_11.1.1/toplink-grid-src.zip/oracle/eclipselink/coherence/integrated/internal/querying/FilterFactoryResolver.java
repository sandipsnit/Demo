// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.internal.querying;

import java.lang.reflect.Constructor;
import java.security.AccessController;

import oracle.eclipselink.coherence.IntegrationProperties;
import oracle.eclipselink.coherence.exceptions.IntegrationException;
import oracle.eclipselink.coherence.integrated.querying.FilterFactory;

import org.eclipse.persistence.internal.security.PrivilegedAccessHelper;
import org.eclipse.persistence.internal.security.PrivilegedGetConstructorFor;
import org.eclipse.persistence.internal.security.PrivilegedInvokeConstructor;
import org.eclipse.persistence.sessions.Session;

/**
 * This class is used to create the configured FilterFactory implementation. The
 * FilterFactory implementation to use is configured by specifying the
 * FilterFactory implementation's class name through the PU/session level
 * property "eclipselink.coherence.filter-factory"
 */
public class FilterFactoryResolver {
    
    protected static FilterFactory factory;
    
    public static FilterFactory resolve(Session session){
        if (factory != null){
            return factory;
        }
        String className = (String) session.getProperty(IntegrationProperties.FILTER_FACTORY_CLASS_NAME);
        if (className == null){
            factory = new EclipseLinkFilterFactory();
            return factory;
        }
        Class filterFactory;
        try {
            filterFactory = session.getPlatform().getConversionManager().getLoader().loadClass(className);
        if (PrivilegedAccessHelper.shouldUsePrivilegedAccess()){
            Constructor constructor = (Constructor)AccessController.doPrivileged(new PrivilegedGetConstructorFor(filterFactory, new Class[0], true));
            factory = (FilterFactory) AccessController.doPrivileged(new PrivilegedInvokeConstructor(constructor, new Object[0]));
        } else {
            Constructor constructor = PrivilegedAccessHelper.getDeclaredConstructorFor(filterFactory, new Class[0], true);
            factory = (FilterFactory) PrivilegedAccessHelper.invokeConstructor(constructor, new Object[0]);
            
        }
        return factory;
        } catch (Exception e) {
            throw IntegrationException.unableToInstantiateFilterFactory(className, e);
        }
    }

}
