// Copyright (c) 1998, 2009, Oracle and/or its affiliates.All rights reserved. 
package oracle.eclipselink.coherence.integrated.querying;

import oracle.eclipselink.coherence.integrated.internal.querying.CoherenceRedirector;

import org.eclipse.persistence.descriptors.ClassDescriptor;
import org.eclipse.persistence.internal.sessions.AbstractSession;
import org.eclipse.persistence.internal.sessions.UnitOfWorkImpl;
import org.eclipse.persistence.queries.DatabaseQuery;
import org.eclipse.persistence.queries.DeleteObjectQuery;
import org.eclipse.persistence.queries.QueryRedirector;
import org.eclipse.persistence.sessions.Record;
import org.eclipse.persistence.sessions.Session;

/**
 * <p>
 * <b>Purpose:</b> This Query Redirector should be set on any class that is
 * stored within Coherence and Coherence will be used for data storage. With
 * this Redirector set TopLink will not issue any SQL for updates. Coherence
 * will be responsible for all database interaction. Developers should set the
 * Coherence Cache name that corresponds to this class in a descriptor property
 * called "coherence.cache.name". Each class should have its own Cache unless
 * the PK's of the instances are unique amoung all classes stored in a single
 * cache
 * 
 * This Redirector can be set on the class descriptor through a Session or
 * Descriptor customizer or annotations.
 * 
 * @see org.eclipse.persistence.descriptors.ClassDescriptor.
 *      setDefaultInsertQueryRedirector(QueryRedirector)
 * @see org.eclipse.persistence.annotations.QueryRedirectors
 * @author Gordon Yorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class DeleteObjectThroughCoherence extends CoherenceRedirector implements QueryRedirector {

    public Object invokeQuery(DatabaseQuery query, Record arguments, Session session) {
        ClassDescriptor descriptor = query.getDescriptor();
        if (query.shouldMaintainCache()) {
            if (session.isUnitOfWork()) {
                ((UnitOfWorkImpl) session).addObjectDeletedDuringCommit(((DeleteObjectQuery) query).getObject(), descriptor);
            } else {
                ((AbstractSession) session).getIdentityMapAccessorInstance().removeFromIdentityMap(((DeleteObjectQuery) query).getPrimaryKey(), descriptor.getJavaClass(), descriptor, ((DeleteObjectQuery) query).getObject());
            }
        }
        // prevent the write to the database as Coherence will write for us
        return null;
    }

}
