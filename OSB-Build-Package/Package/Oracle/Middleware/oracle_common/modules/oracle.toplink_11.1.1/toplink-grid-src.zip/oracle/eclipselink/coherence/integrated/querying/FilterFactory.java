// Copyright (c) 1998, 2010, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.querying;

import oracle.eclipselink.coherence.integrated.internal.querying.FilterExtractor;

import org.eclipse.persistence.expressions.Expression;
import org.eclipse.persistence.internal.queries.ReportItem;
import org.eclipse.persistence.internal.sessions.AbstractSession;
import org.eclipse.persistence.queries.ObjectLevelReadQuery;
import org.eclipse.persistence.queries.ReportQuery;
import org.eclipse.persistence.sessions.Record;
import org.eclipse.persistence.sessions.Session;

import com.tangosol.util.Filter;
import com.tangosol.util.InvocableMap;
import com.tangosol.util.InvocableMap.EntryProcessor;

/**
 * <p>
 * <b>Purpose:</b> This interface provides the template for implementations of a Filter Factory.  The
 * Filter Factory is responsible for translating from EclipseLink queries to Coherence Filters.
 * Custom implementations can be created and used by setting the class name within the Persistence Unit Property "eclipselink.coherence.filter-factory".
 * Implementations must have a default constructor.
 * 
 * @author Gordon Yorke
 * @since Oracle TopLink 11g (11.1.1.4.0)
 */

public interface FilterFactory {
    
    /**
     * This constant represents a failure to translate the Filter.  Any factory that is unable to translate the filter must return this value.
     */
    public static final Filter NO_FILTER = new Filter() {
        public boolean evaluate(Object obj) {
            return false;
        }
    };

    /**
     * Given the query and the provided arguments translate this query into a Coherence Filter
     */
    
    public Filter create(ObjectLevelReadQuery query, Record args, Session session);
    
    /**
     * Creates a valueExtract that should be used for this Expression.
     */
    public FilterExtractor createValueExtractor(Expression baseExpression, AbstractSession session);

    /**
     * Translates ReportQueryItem into an equivalent Coherence aggregation artifact.  Called when the Query is returning aggregations
     */
    public InvocableMap.EntryAggregator createAggregator(ReportItem item, ReportQuery query, Record args, AbstractSession session);

    /**
     * Create a value Extraction to return the selection of the ReportQuery
     */
    public EntryProcessor createValueExtractor(ReportItem item, ReportQuery query, Record args, AbstractSession session);
    
}
