// Copyright (c) 1998, 2009, Oracle and/or its affiliates.All rights reserved. 
package oracle.eclipselink.coherence.integrated.querying;

import oracle.eclipselink.coherence.integrated.internal.querying.CoherenceRedirector;

import org.eclipse.persistence.internal.sessions.AbstractRecord;
import org.eclipse.persistence.internal.sessions.AbstractSession;
import org.eclipse.persistence.queries.DatabaseQuery;
import org.eclipse.persistence.queries.QueryRedirector;
import org.eclipse.persistence.sessions.Record;
import org.eclipse.persistence.sessions.Session;

/**
 * <p>
 * <b>Purpose:</b> This Query Redirector should be set on any query for any
 * class where a default Query Redirector is already set but the user wishes for
 * the default redirector to not be used.
 * 
 * @see org.eclipse.persistence.queryframework.DatabaseQuery.setRedirector(
 *      QueryRedirector))
 * 
 * @author Gordon Yorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class IgnoreDefaultRedirector extends CoherenceRedirector implements QueryRedirector {

    public Object invokeQuery(DatabaseQuery query, Record arguments, Session session) {
        query.setDoNotRedirect(true);
        return ((AbstractSession)session).executeQuery(query, (AbstractRecord)arguments);
    }

}
