// Copyright (c) 1998, 2011, Oracle and/or its affiliates. 
// All rights reserved. 
package oracle.eclipselink.coherence.integrated.querying;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import oracle.eclipselink.coherence.integrated.internal.cache.CoherenceCacheHelper;
import oracle.eclipselink.coherence.integrated.internal.querying.CoherenceRedirector;

import org.eclipse.persistence.descriptors.ClassDescriptor;
import org.eclipse.persistence.internal.helper.InvalidObject;
import org.eclipse.persistence.internal.identitymaps.CacheKey;
import org.eclipse.persistence.internal.sessions.AbstractRecord;
import org.eclipse.persistence.internal.sessions.AbstractSession;
import org.eclipse.persistence.internal.sessions.UnitOfWorkImpl;
import org.eclipse.persistence.queries.DatabaseQuery;
import org.eclipse.persistence.queries.QueryRedirector;
import org.eclipse.persistence.queries.ReadObjectQuery;
import org.eclipse.persistence.sessions.Record;
import org.eclipse.persistence.sessions.Session;

import com.tangosol.net.NamedCache;
import com.tangosol.util.Filter;

/**
 * <p>
 * <b>Purpose:</b> This Query Redirector should be set on any class or query
 * where the user wants Coherence to be checked for data instead of the database
 * and CoherenceInterceptor has been set on the Descriptor. With this Redirector
 * set TopLink will not issue any SQL for Reads unless the query can not be
 * translated into a Coherence filter. And primary key queries will only access
 * Coherence once for each query.
 * 
 * Developers should set the Coherence Cache name that corresponds to this class
 * in a descriptor property called "coherence.cache.name". Each class should
 * have its own Cache unless the PK's of the instances are unique amoung all
 * classes stored in a single cache
 * 
 * This Redirector can be set on the class descriptor through a Session or
 * Descriptor customizer or annotations. This Redirector may be used on a per
 * query basis as well.
 * 
 * @see org.eclipse.persistence.descriptors.ClassDescriptor.
 *      setDefaultInsertQueryRedirector(QueryRedirector)
 * @see org.eclipse.persistence.annotations.QueryRedirectors
 * 
 * @author Gordon Yorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class ReadObjectFromCoherence extends CoherenceRedirector implements QueryRedirector {

    public Object invokeQuery(DatabaseQuery query, Record arguments, Session session) {
        Object result = null;
        if (session.isUnitOfWork()){
            //check the UOW identityMap first
            result = query.checkEarlyReturn((AbstractSession) session, (AbstractRecord)arguments);
            if (result != null){
                return result;
            }
        }
        Object selectionKey = ((ReadObjectQuery)query).getSelectionId();
        Object selectionObject = ((ReadObjectQuery)query).getSelectionObject();
        if (selectionObject != null) {
            if (selectionKey == null) {
                selectionKey = query.getDescriptor().getObjectBuilder().extractPrimaryKeyFromObject(selectionObject, (AbstractSession)session, true);
                if (selectionKey == null) {
                    // Has a null primary key, so must not exist.
                    return InvalidObject.instance;
                }
                // Must be checked separately as the expression and row is not yet set.
            }
        }
        if (selectionKey != null){
                result = CoherenceCacheHelper.getFromCoherence(query.getDescriptor(), (AbstractSession)session, CoherenceCacheHelper.getNamedCache(query.getDescriptor().getJavaClass(), session), selectionKey, shouldTranslatePKs(session));
        } else {
            //check to see if query is on pk
            selectionKey = query.getDescriptor().getObjectBuilder().extractPrimaryKeyFromExpression(true, query.getSelectionCriteria(), (AbstractRecord)arguments, (AbstractSession) session);
            if (selectionKey != null){
                result = CoherenceCacheHelper.getFromCoherence(query.getDescriptor(), (AbstractSession)session, CoherenceCacheHelper.getNamedCache(query.getDescriptor().getJavaClass(),session), selectionKey, shouldTranslatePKs(session));
            }else{
            
            Filter filter = getFilterFactory(session).create((ReadObjectQuery) query, arguments, session);
            if (filter == FilterFactory.NO_FILTER) {
                return getTranslationFailureDelegate(session).translationFailed(query, arguments, session);
            }
            NamedCache cache = getNamedCache(query.getDescriptor().getRootDescriptor(), session);
            Set set = cache.entrySet(filter);
            if (set.size() == 0)
                return null;
            Map.Entry entry = (Map.Entry) set.iterator().next();
            result = entry.getValue();
            result = CoherenceCacheHelper.composeEntity(entry.getKey(), result, query.getDescriptor(), (AbstractSession)session, false, shouldTranslatePKs(session));
            }
        }
        if (result != null && session.isUnitOfWork()) {
            ClassDescriptor descriptor = query.getDescriptor();
            Object pk = selectionKey;
            if (pk == null){
                pk = descriptor.getObjectBuilder().extractPrimaryKeyFromObject(result, (AbstractSession) session);
            }
            CacheKey parentKey = new CacheKey(pk);
            parentKey.setObject(result);
            UnitOfWorkImpl uow = (UnitOfWorkImpl)session;
            return uow.cloneAndRegisterObject(result, parentKey, descriptor);
        }
        return result;
    }

}
