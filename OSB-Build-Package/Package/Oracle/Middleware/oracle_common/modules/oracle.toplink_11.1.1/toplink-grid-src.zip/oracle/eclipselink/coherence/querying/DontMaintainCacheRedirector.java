// Copyright (c) 1998, 2009, Oracle and/or its affiliates.All rights reserved. 
package oracle.eclipselink.coherence.querying;

import oracle.eclipselink.coherence.integrated.internal.querying.CoherenceRedirector;

import org.eclipse.persistence.queries.DatabaseQuery;
import org.eclipse.persistence.queries.QueryRedirector;
import org.eclipse.persistence.sessions.Record;
import org.eclipse.persistence.sessions.Session;

/**
 * 
 * <b>Purpose:</b> This Query Redirector should be set as the Default
 * QueryRedirector on any class that does not need to access the cache. This
 * should be considered a performance optimization.
 * 
 * This Redirector can be set on the class descriptor through a Session or
 * Descriptor customizer or annotations.
 * 
 * @see org.eclipse.persistence.descriptors.ClassDescriptor.
 *      setDefaultQueryRedirector(QueryRedirector)
 * @see org.eclipse.persistence.annotations.QueryRedirectors
 * 
 * @author gorke
 * @since Oracle TopLink 11g (11.1.1.0.0)
 */
public class DontMaintainCacheRedirector extends CoherenceRedirector implements QueryRedirector {

    public Object invokeQuery(DatabaseQuery query, Record arguments, Session session) {
        query.setDoNotRedirect(true);
        query.dontMaintainCache();
        return session.executeQuery(query);
    }
}
