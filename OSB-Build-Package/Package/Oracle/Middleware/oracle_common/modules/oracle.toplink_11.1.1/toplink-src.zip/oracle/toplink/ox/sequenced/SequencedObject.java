// Copyright (c) 1998, 2007, Oracle. All rights reserved. 
package oracle.toplink.ox.sequenced;

import java.util.List;

public interface SequencedObject {
	List<Setting> getSettings();
}